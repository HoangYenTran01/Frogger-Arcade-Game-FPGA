`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 12:32:55 AM
// Design Name: 
// Module Name: scoretext
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module scoretext(
    input [5:0] x,
    input [4:0] y,
    output [3:0] R,
    output [3:0] G,
    output [3:0] B
    );
    
    
    reg[11:0] log [0:1023];
    initial $readmemh("score.mem", log);
    
    wire [9:0] pos;
    assign pos = x + y * 64;
    
    assign R = log[pos][11:8];
    assign G = log[pos][7:4];
    assign B = log[pos][3:0];
    
    
endmodule
