`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/04/2025 09:50:35 PM
// Design Name: 
// Module Name: road_death_test
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module log_death_test(

    );
    
    reg clk, reset;
  // positions in {..., ypos1, y-pos0, ..., xpos1, xpos0}
  reg [2:0] car_pos_x1, car_pos_y1;
    reg [2:0] car_pos_x2, car_pos_y2;
  // sizes in {..., obj1height, obj0height, ..., obj1width, obj0width}
  reg [3:0] car_size1;
  reg [3:0] car_size2;
  // frog position in {frogpos_y, frogpos_x}
  reg [5:0] frog_pos;
  wire death;  // death signal is active high
  
   water_death #(
      .LOG_NUMBER(2),
        .X_BITS(3),
      .Y_BITS(3),
      .MAX_OBJ_WIDTH_BITS(2),
      .MAX_OBJ_HEIGHT_BITS(2)
  ) dut (
      .clk(clk),
      .reset(reset),
      .log_pos({{car_pos_y2, car_pos_y1, car_pos_x2, car_pos_x1}}),
      .log_size({car_size2, car_size1}),
      .frog_pos(frog_pos),
      .death(death)
  );
  
  initial begin
  clk <= 1'b0;
  reset <= 1'b0;
  car_size1 <= 4'b0110;
  car_pos_x1 <= 3'b000;
  car_pos_y1 <= 3'b010;
  car_size2 <= 4'b0101;
  car_pos_x2 <= 3'b011;
  car_pos_y2 <= 3'b010;
  frog_pos <= 6'b010011;
  #10 reset <= 1'b1;
  
  end
  
  always begin
    #10 clk <= ~clk;
    car_pos_x1 <= car_pos_x1 + 1;
    car_pos_x2 <= car_pos_x2 + 1;
  end
endmodule
