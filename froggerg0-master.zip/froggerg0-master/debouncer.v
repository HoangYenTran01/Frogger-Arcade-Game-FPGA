`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/01/2025 08:14:33 PM
// Design Name: 
// Module Name: debouncer
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module debouncer(clk, reset, insignal, outsignal);
///USE MEALY STATE ENCODING
    input clk;
    input reset;
    input insignal;
    reg [20:0] tmp; //= 20'd0; // NEED TO CHANGE
    reg output_exist; //= 1'b0;
    output outsignal;
    parameter S0 = 1'd0, S1 = 1'd1, S2 = 4'd9;
    parameter MAX = 2000000;
//    parameter R1 = 1'd0, R2 = 1'd1; //added
    reg [3:0] state; // = S0;  // register that store the state
//    reg reset_status = 1'b0;//added 
    always @ (posedge clk or negedge reset) 
    begin
        if (! reset)
        begin
                state <= S0;
                output_exist <= 1'b0;tmp <= 1'd0;
        end
        else 
        begin
            case (state)
                S0:
                    if (insignal == 1'b0) 
                    begin
                        state <= S0;
                    end
                    else if (insignal == 1'b1) 
                    begin   
                        state <= S1;
                        tmp <= tmp + 1;
                    end
                S1: 
                    if  (insignal == 1'b0)
                    begin
                        state <= S0;
                        tmp <= 1'b0;
                    end
                    
                    else if  (insignal == 1'b1 && (tmp < MAX)) //20'd1000000
                    begin
                        state <= S1;
                        tmp <= tmp +1;
                    end                    
                    else if  (insignal == 1'b1 && tmp >= MAX) //check for number of string //20'd1000000
                    begin 
                        state <= S2;
                        tmp <= tmp + 1;
                        output_exist <= 1'b1;
                    end 
                    
               S2: 
                    if  (insignal == 1'b0)
                    begin
                        state <= S0;
                        tmp <= 1'd0;
                        output_exist <= 1'b0;
                    end
                    
                    else if  (insignal == 1'b1)
                    begin
                        state <= S2;
                        tmp <= tmp +1;
                        output_exist <= 1'b1;
                    end     
                  
            endcase   
        end //end else statement   
    end //always  
    assign outsignal = output_exist;             
endmodule