`timescale 1ns / 1ps

module decoration(
    input  wire CLK,
    input  wire [9:0] x,
    input  wire [8:0] y,
    input  wire [7:0] random_num,
    input  wire [7:0] hit,

    output reg        overlay_on,
    output reg [3:0]  R,
    output reg [3:0]  G,
    output reg [3:0]  B,
    output reg [99:0] obj_thickness,
    output reg [139:0] car_x_pos,  car_thickness,
    output reg [169:0] log_x_pos,  log_thickness,
    output reg [125:0] car_y_pos, 
    output reg [152:0] log_y_pos,
    output reg [99:0] spacing
);

    //-----------------------------------------------------------
    // CONSTANTS
    //-----------------------------------------------------------
    localparam STEP = 1;

    // Row 1: logs
    localparam [9:0] OBJ1_W   = 10'd128;
    localparam [9:0] OBJ1_H   = 10'd32;
    localparam [9:0] OBJ1_Y   = 10'd64;   // 80 - 16
    localparam [9:0] OBJ1_GAP = 10'd64;   // spacing between logs

    // Row 2: turtles
    localparam [9:0] OBJ2_W   = 10'd64;
    localparam [9:0] OBJ2_H   = 10'd32;
    localparam [9:0] OBJ2_Y   = 10'd96;   // 112 - 16
    localparam [9:0] OBJ2_GAP = 10'd96;

    // Row 3: logs
    localparam [9:0] OBJ3_W   = 10'd160;
    localparam [9:0] OBJ3_H   = 10'd32;
    localparam [9:0] OBJ3_Y   = 10'd128;  // 144 - 16
    localparam [9:0] OBJ3_GAP = 10'd96;

    // Row 4: logs
    localparam [9:0] OBJ4_W   = 10'd96;
    localparam [9:0] OBJ4_H   = 10'd32;
    localparam [9:0] OBJ4_Y   = 10'd160;  // 176 - 16
    localparam [9:0] OBJ4_GAP = 10'd64;

    // Row 5: turtles
    localparam [9:0] OBJ5_W   = 10'd96;
    localparam [9:0] OBJ5_H   = 10'd32;
    localparam [9:0] OBJ5_Y   = 10'd192;  // 208 - 16
    localparam [9:0] OBJ5_GAP = 10'd32;

    // Row 6: trucks
    localparam [9:0] OBJ6_W   = 10'd32;
    localparam [9:0] OBJ6_H   = 10'd32;
    localparam [9:0] OBJ6_Y   = 10'd256;  // 272 - 16
    localparam [9:0] OBJ6_GAP = 10'd96;

    // Row 7: cars
    localparam [9:0] OBJ7_W   = 10'd32;
    localparam [9:0] OBJ7_H   = 10'd32;
    localparam [9:0] OBJ7_Y   = 10'd288;  // 304 - 16
    localparam [9:0] OBJ7_GAP = 10'd96;

    // Row 8: cars
    localparam [9:0] OBJ8_W   = 10'd32;
    localparam [9:0] OBJ8_H   = 10'd32;
    localparam [9:0] OBJ8_Y   = 10'd320;  // 336 - 16
    localparam [9:0] OBJ8_GAP = 10'd96;

    // Row 9: cars
    localparam [9:0] OBJ9_W   = 10'd32;
    localparam [9:0] OBJ9_H   = 10'd32;
    localparam [9:0] OBJ9_Y   = 10'd352;  // 368 - 16
    localparam [9:0] OBJ9_GAP = 10'd96;

    // Row10: cars
    localparam [9:0] OBJ10_W   = 10'd32;
    localparam [9:0] OBJ10_H   = 10'd32;
    localparam [9:0] OBJ10_Y   = 10'd384; // 400 - 16
    localparam [9:0] OBJ10_GAP = 10'd96;

    //-----------------------------------------------------------
    // POSITIONS: multiple objects per row
    //-----------------------------------------------------------
    // Row 1: three logs (right)
    reg signed [11:0] xpos1a  = -$signed(OBJ1_W);
    reg signed [11:0] xpos1b  = -$signed(OBJ1_W) - $signed(OBJ1_W + OBJ1_GAP);
    reg signed [11:0] xpos1c  = -$signed(OBJ1_W) - 2*$signed(OBJ1_W + OBJ1_GAP);

    // Row 2: four turtles (left)
    reg signed [11:0] xpos2a  =  $signed(OBJ2_W);
    reg signed [11:0] xpos2b  =  $signed(OBJ2_W) + $signed(OBJ2_W + OBJ2_GAP);
    reg signed [11:0] xpos2c  =  $signed(OBJ2_W) + 2*$signed(OBJ2_W + OBJ2_GAP);
    reg signed [11:0] xpos2d  =  $signed(OBJ2_W) + 3*$signed(OBJ2_W + OBJ2_GAP);

    // Row 3: two logs (right)
    reg signed [11:0] xpos3a  = -$signed(OBJ3_W);
    reg signed [11:0] xpos3b  = -$signed(OBJ3_W) - $signed(OBJ3_W + OBJ3_GAP);

    // Row 4: three logs (right)
    reg signed [11:0] xpos4a  = -$signed(OBJ4_W);
    reg signed [11:0] xpos4b  = -$signed(OBJ4_W) - $signed(OBJ4_W + OBJ4_GAP);
    reg signed [11:0] xpos4c  = -$signed(OBJ4_W) - 2*$signed(OBJ4_W + OBJ4_GAP);

    // Row 5: five turtles (left)
    reg signed [11:0] xpos5a  =  $signed(OBJ5_W);
    reg signed [11:0] xpos5b  =  $signed(OBJ5_W) + $signed(OBJ5_W + OBJ5_GAP);
    reg signed [11:0] xpos5c  =  $signed(OBJ5_W) + 2*$signed(OBJ5_W + OBJ5_GAP);
    reg signed [11:0] xpos5d  =  $signed(OBJ5_W) + 3*$signed(OBJ5_W + OBJ5_GAP);
    reg signed [11:0] xpos5e  =  $signed(OBJ5_W) + 4*$signed(OBJ5_W + OBJ5_GAP);

    // Row 6: two trucks (left)
    reg signed [11:0] xpos6a  =  $signed(OBJ6_W) + 14;
    reg signed [11:0] xpos6b  =  $signed(OBJ6_W) + $signed(OBJ6_W + OBJ6_GAP) + 14;

    // Row 7: three cars (right)
    reg signed [11:0] xpos7a  = -$signed(OBJ7_W) + 29;
    reg signed [11:0] xpos7b  = -$signed(OBJ7_W) - $signed(OBJ7_W + OBJ7_GAP) + 29;
    reg signed [11:0] xpos7c  = -$signed(OBJ7_W) - 2*$signed(OBJ7_W + OBJ7_GAP) + 29;

    // Row 8: three cars (left)
    reg signed [11:0] xpos8a  =  $signed(OBJ8_W) + 68;
    reg signed [11:0] xpos8b  =  $signed(OBJ8_W) + $signed(OBJ8_W + OBJ8_GAP) + 68;
    reg signed [11:0] xpos8c  =  $signed(OBJ8_W) + 2*$signed(OBJ8_W + OBJ8_GAP) + 68;

    // Row 9: three cars (right)
    reg signed [11:0] xpos9a  = -$signed(OBJ9_W) + 71;
    reg signed [11:0] xpos9b  = -$signed(OBJ9_W) - $signed(OBJ9_W + OBJ9_GAP) + 71;
    reg signed [11:0] xpos9c  = -$signed(OBJ9_W) - 2*$signed(OBJ9_W + OBJ9_GAP) + 71;

    // Row10: three cars (left)
    reg signed [11:0] xpos10a =  $signed(OBJ10_W) + 52;
    reg signed [11:0] xpos10b =  $signed(OBJ10_W) + $signed(OBJ10_W + OBJ10_GAP) + 52;
    reg signed [11:0] xpos10c =  $signed(OBJ10_W) + 2*$signed(OBJ10_W + OBJ10_GAP) + 52;

    //-----------------------------------------------------------
    // SPEED DIVIDER
    //-----------------------------------------------------------
    reg [30:0] speed = 0;

    always @(posedge CLK) begin
        speed <= speed + 1;

        if (speed == 31'd5_000_000) begin
            speed <= 0;

            // ROW 1: logs move RIGHT
            if (xpos1a < 640) xpos1a <= xpos1a + 3*STEP; else xpos1a <= -$signed(OBJ1_W);
            if (xpos1b < 640) xpos1b <= xpos1b + 3*STEP; else xpos1b <= -$signed(OBJ1_W);
            if (xpos1c < 640) xpos1c <= xpos1c + 3*STEP; else xpos1c <= -$signed(OBJ1_W);

            // ROW 2: turtles move LEFT
            if (xpos2a > -$signed(OBJ2_W)) xpos2a <= xpos2a - 3*STEP; else xpos2a <= 640;
            if (xpos2b > -$signed(OBJ2_W)) xpos2b <= xpos2b - 3*STEP; else xpos2b <= 640;
            if (xpos2c > -$signed(OBJ2_W)) xpos2c <= xpos2c - 3*STEP; else xpos2c <= 640;
            if (xpos2d > -$signed(OBJ2_W)) xpos2d <= xpos2d - 3*STEP; else xpos2d <= 640;

            // ROW 3: logs move RIGHT
            if (xpos3a < 640) xpos3a <= xpos3a + 4*STEP; else xpos3a <= -$signed(OBJ3_W);
            if (xpos3b < 640) xpos3b <= xpos3b + 4*STEP; else xpos3b <= -$signed(OBJ3_W);

            // ROW 4: logs move RIGHT
            if (xpos4a < 640) xpos4a <= xpos4a + 2*STEP; else xpos4a <= -$signed(OBJ4_W);
            if (xpos4b < 640) xpos4b <= xpos4b + 2*STEP; else xpos4b <= -$signed(OBJ4_W);
            if (xpos4c < 640) xpos4c <= xpos4c + 2*STEP; else xpos4c <= -$signed(OBJ4_W);

            // ROW 5: turtles move LEFT
            if (xpos5a > -$signed(OBJ5_W)) xpos5a <= xpos5a - 3*STEP; else xpos5a <= 640;
            if (xpos5b > -$signed(OBJ5_W)) xpos5b <= xpos5b - 3*STEP; else xpos5b <= 640;
            if (xpos5c > -$signed(OBJ5_W)) xpos5c <= xpos5c - 3*STEP; else xpos5c <= 640;
            if (xpos5d > -$signed(OBJ5_W)) xpos5d <= xpos5d - 3*STEP; else xpos5d <= 640;
            if (xpos5e > -$signed(OBJ5_W)) xpos5e <= xpos5e - 3*STEP; else xpos5e <= 640;

            // ROW 6: trucks move LEFT
            if (xpos6a > -$signed(OBJ6_W)) xpos6a <= xpos6a - 3*STEP; else xpos6a <= 640;
            if (xpos6b > -$signed(OBJ6_W)) xpos6b <= xpos6b - 3*STEP; else xpos6b <= 640;

            // ROW 7: cars move RIGHT
            if (xpos7a < 640) xpos7a <= xpos7a + 2*STEP; else xpos7a <= -$signed(OBJ7_W);
            if (xpos7b < 640) xpos7b <= xpos7b + 2*STEP; else xpos7b <= -$signed(OBJ7_W);
            if (xpos7c < 640) xpos7c <= xpos7c + 2*STEP; else xpos7c <= -$signed(OBJ7_W);

            // ROW 8: cars move LEFT
            if (xpos8a > -$signed(OBJ8_W)) xpos8a <= xpos8a - 3*STEP; else xpos8a <= 640;
            if (xpos8b > -$signed(OBJ8_W)) xpos8b <= xpos8b - 3*STEP; else xpos8b <= 640;
            if (xpos8c > -$signed(OBJ8_W)) xpos8c <= xpos8c - 3*STEP; else xpos8c <= 640;

            // ROW 9: cars move RIGHT
            if (xpos9a < 640) xpos9a <= xpos9a + 2*STEP; else xpos9a <= -$signed(OBJ9_W);
            if (xpos9b < 640) xpos9b <= xpos9b + 2*STEP; else xpos9b <= -$signed(OBJ9_W);
            if (xpos9c < 640) xpos9c <= xpos9c + 2*STEP; else xpos9c <= -$signed(OBJ9_W);

            // ROW10: cars move LEFT
            if (xpos10a > -$signed(OBJ10_W)) xpos10a <= xpos10a - 2*STEP; else xpos10a <= 640;
            if (xpos10b > -$signed(OBJ10_W)) xpos10b <= xpos10b - 2*STEP; else xpos10b <= 640;
            if (xpos10c > -$signed(OBJ10_W)) xpos10c <= xpos10c - 2*STEP; else xpos10c <= 640;
        end
    end

    //-----------------------------------------------------------
    // DRAWING LOGIC
    //-----------------------------------------------------------
    reg [4:0] texX, texY;

    wire [3:0] logR,  logG,  logB;
    wire [3:0] turtR, turtG, turtB;
    wire [3:0] carR,  carG,  carB;
    wire [3:0] trukR, trukG, trukB;
    wire [3:0] pinkcarR, pinkcarG, pinkcarB;

    // signed x for all comparisons
    wire signed [11:0] x_s = $signed({2'b00, x});
    reg  signed [11:0] dx1;

    // sprite ROMs (textured .mem files)
    log  L0 (.x(texX), .y(texY), .R(logR),  .G(logG),  .B(logB));
    turt T0(.x(texX), .y(texY), .R(turtR), .G(turtG), .B(turtB), .oneHundredMHz(CLK));
    car  C0 (.x(texX), .y(texY), .R(carR),  .G(carG),  .B(carB));
    truk K0(.x(texX), .y(texY), .R(trukR), .G(trukG), .B(trukB));
    pinkcar  PC0 (.x(texX), .y(texY), .R(pinkcarR),  .G(pinkcarG),  .B(pinkcarB));

    // fixed brown for logs (using log.mem as a mask only)
    localparam [3:0] LOG_R_FIX = 4'hC;
    localparam [3:0] LOG_G_FIX = 4'h7;
    localparam [3:0] LOG_B_FIX = 4'h0;

    // transparency helper: treat black as invisible
    function sprite_nonzero;
        input [3:0] r, g, b;
        begin
            sprite_nonzero = (r != 4'd0) || (g != 4'd0) || (b != 4'd0);
        end
    endfunction

    always @* begin
        texY      = y[4:0];
        overlay_on = 0;
        R = 0; G = 0; B = 0;

        //---------------------------------------------------
        // ROW 1: logs
        //---------------------------------------------------
        if (!overlay_on &&
            (x_s >= xpos1a) && (x_s < xpos1a + $signed(OBJ1_W)) &&
            (y   >= OBJ1_Y) && (y   < OBJ1_Y + OBJ1_H)) begin
            dx1  = x_s - xpos1a;
            texX = dx1[4:0];
            if (sprite_nonzero(logR, logG, logB)) begin
                overlay_on = 1;
                R = logR; G = logG; B = logB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos1b) && (x_s < xpos1b + $signed(OBJ1_W)) &&
                 (y   >= OBJ1_Y) && (y   < OBJ1_Y + OBJ1_H)) begin
            dx1  = x_s - xpos1b;
            texX = dx1[4:0];
            if (sprite_nonzero(logR, logG, logB)) begin
                overlay_on = 1;
                R = logR; G = logG; B = logB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos1c) && (x_s < xpos1c + $signed(OBJ1_W)) &&
                 (y   >= OBJ1_Y) && (y   < OBJ1_Y + OBJ1_H)) begin
            dx1  = x_s - xpos1c;
            texX = dx1[4:0];
            if (sprite_nonzero(logR, logG, logB)) begin
                overlay_on = 1;
                R = logR; G = logG; B = logB;
            end
        end

        //---------------------------------------------------
        // ROW 2: turtles
        //---------------------------------------------------
        if (!overlay_on &&
            (x_s >= xpos2a) && (x_s < xpos2a + $signed(OBJ2_W)) &&
            (y   >= OBJ2_Y) && (y   < OBJ2_Y + OBJ2_H)) begin
            dx1  = x_s - xpos2a;
            texX = dx1[4:0];
            if (sprite_nonzero(turtR, turtG, turtB)) begin
                overlay_on = 1;
                R = turtR; G = turtG; B = turtB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos2b) && (x_s < xpos2b + $signed(OBJ2_W)) &&
                 (y   >= OBJ2_Y) && (y   < OBJ2_Y + OBJ2_H)) begin
            dx1  = x_s - xpos2b;
            texX = dx1[4:0];
            if (sprite_nonzero(turtR, turtG, turtB)) begin
                overlay_on = 1;
                R = turtR; G = turtG; B = turtB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos2c) && (x_s < xpos2c + $signed(OBJ2_W)) &&
                 (y   >= OBJ2_Y) && (y   < OBJ2_Y + OBJ2_H)) begin
            dx1  = x_s - xpos2c;
            texX = dx1[4:0];
            if (sprite_nonzero(turtR, turtG, turtB)) begin
                overlay_on = 1;
                R = turtR; G = turtG; B = turtB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos2d) && (x_s < xpos2d + $signed(OBJ2_W)) &&
                 (y   >= OBJ2_Y) && (y   < OBJ2_Y + OBJ2_H)) begin
            dx1  = x_s - xpos2d;
            texX = dx1[4:0];
            if (sprite_nonzero(turtR, turtG, turtB)) begin
                overlay_on = 1;
                R = turtR; G = turtG; B = turtB;
            end
        end

        //---------------------------------------------------
        // ROW 3: logs
        //---------------------------------------------------
        if (!overlay_on &&
            (x_s >= xpos3a) && (x_s < xpos3a + $signed(OBJ3_W)) &&
            (y   >= OBJ3_Y) && (y   < OBJ3_Y + OBJ3_H)) begin
            dx1  = x_s - xpos3a;
            texX = dx1[4:0];
            if (sprite_nonzero(logR, logG, logB)) begin
                overlay_on = 1;
                R = logR; G = logG; B = logB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos3b) && (x_s < xpos3b + $signed(OBJ3_W)) &&
                 (y   >= OBJ3_Y) && (y   < OBJ3_Y + OBJ3_H)) begin
            dx1  = x_s - xpos3b;
            texX = dx1[4:0];
            if (sprite_nonzero(logR, logG, logB)) begin
                overlay_on = 1;
                R = logR; G = logG; B = logB;
            end
        end

        //---------------------------------------------------
        // ROW 4: logs
        //---------------------------------------------------
        if (!overlay_on &&
            (x_s >= xpos4a) && (x_s < xpos4a + $signed(OBJ4_W)) &&
            (y   >= OBJ4_Y) && (y   < OBJ4_Y + OBJ4_H)) begin
            dx1  = x_s - xpos4a;
            texX = dx1[4:0];
            if (sprite_nonzero(logR, logG, logB)) begin
                overlay_on = 1;
                R = logR; G = logG; B = logB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos4b) && (x_s < xpos4b + $signed(OBJ4_W)) &&
                 (y   >= OBJ4_Y) && (y   < OBJ4_Y + OBJ4_H)) begin
            dx1  = x_s - xpos4b;
            texX = dx1[4:0];
            if (sprite_nonzero(logR, logG, logB)) begin
                overlay_on = 1;
                R = logR; G = logG; B = logB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos4c) && (x_s < xpos4c + $signed(OBJ4_W)) &&
                 (y   >= OBJ4_Y) && (y   < OBJ4_Y + OBJ4_H)) begin
            dx1  = x_s - xpos4c;
            texX = dx1[4:0];
            if (sprite_nonzero(logR, logG, logB)) begin
                overlay_on = 1;
                R = logR; G = logG; B = logB;
            end
        end

        //---------------------------------------------------
        // ROW 5: turtles
        //---------------------------------------------------
        if (!overlay_on &&
            (x_s >= xpos5a) && (x_s < xpos5a + $signed(OBJ5_W)) &&
            (y   >= OBJ5_Y) && (y   < OBJ5_Y + OBJ5_H)) begin
            dx1  = x_s - xpos5a;
            texX = dx1[4:0];
            if (sprite_nonzero(turtR, turtG, turtB)) begin
                overlay_on = 1;
                R = turtR; G = turtG; B = turtB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos5b) && (x_s < xpos5b + $signed(OBJ5_W)) &&
                 (y   >= OBJ5_Y) && (y   < OBJ5_Y + OBJ5_H)) begin
            dx1  = x_s - xpos5b;
            texX = dx1[4:0];
            if (sprite_nonzero(turtR, turtG, turtB)) begin
                overlay_on = 1;
                R = turtR; G = turtG; B = turtB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos5c) && (x_s < xpos5c + $signed(OBJ5_W)) &&
                 (y   >= OBJ5_Y) && (y   < OBJ5_Y + OBJ5_H)) begin
            dx1  = x_s - xpos5c;
            texX = dx1[4:0];
            if (sprite_nonzero(turtR, turtG, turtB)) begin
                overlay_on = 1;
                R = turtR; G = turtG; B = turtB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos5d) && (x_s < xpos5d + $signed(OBJ5_W)) &&
                 (y   >= OBJ5_Y) && (y   < OBJ5_Y + OBJ5_H)) begin
            dx1  = x_s - xpos5d;
            texX = dx1[4:0];
            if (sprite_nonzero(turtR, turtG, turtB)) begin
                overlay_on = 1;
                R = turtR; G = turtG; B = turtB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos5e) && (x_s < xpos5e + $signed(OBJ5_W)) &&
                 (y   >= OBJ5_Y) && (y   < OBJ5_Y + OBJ5_H)) begin
            dx1  = x_s - xpos5e;
            texX = dx1[4:0];
            if (sprite_nonzero(turtR, turtG, turtB)) begin
                overlay_on = 1;
                R = turtR; G = turtG; B = turtB;
            end
        end

        //---------------------------------------------------
        // ROW 6: trucks
        //---------------------------------------------------
        if (!overlay_on &&
            (x_s >= xpos6a) && (x_s < xpos6a + $signed(OBJ6_W)) &&
            (y   >= OBJ6_Y) && (y   < OBJ6_Y + OBJ6_H)) begin
            dx1  = x_s - xpos6a;
            texX = dx1[4:0];
            if (sprite_nonzero(trukR, trukG, trukB)) begin
                overlay_on = 1;
                R = trukR; G = trukG; B = trukB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos6b) && (x_s < xpos6b + $signed(OBJ6_W)) &&
                 (y   >= OBJ6_Y) && (y   < OBJ6_Y + OBJ6_H)) begin
            dx1  = x_s - xpos6b;
            texX = dx1[4:0];
            if (sprite_nonzero(trukR, trukG, trukB)) begin
                overlay_on = 1;
                R = trukR; G = trukG; B = trukB;
            end
        end

        //---------------------------------------------------
        // ROW 7: cars
        //---------------------------------------------------
        if (!overlay_on &&
            (x_s >= xpos7a) && (x_s < xpos7a + $signed(OBJ7_W)) &&
            (y   >= OBJ7_Y) && (y   < OBJ7_Y + OBJ7_H)) begin
            dx1  = x_s - xpos7a;
            texX = dx1[4:0];
            if (sprite_nonzero(carR, carG, carB)) begin
                overlay_on = 1;
                R = carR; G = carG; B = carB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos7b) && (x_s < xpos7b + $signed(OBJ7_W)) &&
                 (y   >= OBJ7_Y) && (y   < OBJ7_Y + OBJ7_H)) begin
            dx1  = x_s - xpos7b;
            texX = dx1[4:0];
            if (sprite_nonzero(carR, carG, carB)) begin
                overlay_on = 1;
                R = carR; G = carG; B = carB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos7c) && (x_s < xpos7c + $signed(OBJ7_W)) &&
                 (y   >= OBJ7_Y) && (y   < OBJ7_Y + OBJ7_H)) begin
            dx1  = x_s - xpos7c;
            texX = dx1[4:0];
            if (sprite_nonzero(carR, carG, carB)) begin
                overlay_on = 1;
                R = carR; G = carG; B = carB;
            end
        end

        //---------------------------------------------------
        // ROW 8: pink car
        //---------------------------------------------------
        if (!overlay_on &&
            (x_s >= xpos8a) && (x_s < xpos8a + $signed(OBJ8_W)) &&
            (y   >= OBJ8_Y) && (y   < OBJ8_Y + OBJ8_H)) begin
            dx1  = x_s - xpos8a;
            texX = dx1[4:0];
            if (sprite_nonzero(pinkcarR, pinkcarG, pinkcarB)) begin
                overlay_on = 1;
                R = pinkcarR; G = pinkcarG; B = pinkcarB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos8b) && (x_s < xpos8b + $signed(OBJ8_W)) &&
                 (y   >= OBJ8_Y) && (y   < OBJ8_Y + OBJ8_H)) begin
            dx1  = x_s - xpos8b;
            texX = dx1[4:0];
            if (sprite_nonzero(pinkcarR, pinkcarG, pinkcarB)) begin
                overlay_on = 1;
                R = pinkcarR; G = pinkcarG; B = pinkcarB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos8c) && (x_s < xpos8c + $signed(OBJ8_W)) &&
                 (y   >= OBJ8_Y) && (y   < OBJ8_Y + OBJ8_H)) begin
            dx1  = x_s - xpos8c;
            texX = dx1[4:0];
            if (sprite_nonzero(pinkcarR, pinkcarG, pinkcarB)) begin
                overlay_on = 1;
                R = pinkcarR; G = pinkcarG; B = pinkcarB;
            end
        end

        //---------------------------------------------------
        // ROW 9: cars
        //---------------------------------------------------
        if (!overlay_on &&
            (x_s >= xpos9a) && (x_s < xpos9a + $signed(OBJ9_W)) &&
            (y   >= OBJ9_Y) && (y   < OBJ9_Y + OBJ9_H)) begin
            dx1  = x_s - xpos9a;
            texX = dx1[4:0];
            if (sprite_nonzero(carR, carG, carB)) begin
                overlay_on = 1;
                R = carR; G = carG; B = carB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos9b) && (x_s < xpos9b + $signed(OBJ9_W)) &&
                 (y   >= OBJ9_Y) && (y   < OBJ9_Y + OBJ9_H)) begin
            dx1  = x_s - xpos9b;
            texX = dx1[4:0];
            if (sprite_nonzero(carR, carG, carB)) begin
                overlay_on = 1;
                R = carR; G = carG; B = carB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos9c) && (x_s < xpos9c + $signed(OBJ9_W)) &&
                 (y   >= OBJ9_Y) && (y   < OBJ9_Y + OBJ9_H)) begin
            dx1  = x_s - xpos9c;
            texX = dx1[4:0];
            if (sprite_nonzero(carR, carG, carB)) begin
                overlay_on = 1;
                R = carR; G = carG; B = carB;
            end
        end

        //---------------------------------------------------
        // ROW10: pink car
        //---------------------------------------------------
        if (!overlay_on &&
            (x_s >= xpos10a) && (x_s < xpos10a + $signed(OBJ10_W)) &&
            (y   >= OBJ10_Y) && (y   < OBJ10_Y + OBJ10_H)) begin
            dx1  = x_s - xpos10a;
            texX = dx1[4:0];
            if (sprite_nonzero(pinkcarR, pinkcarG, pinkcarB)) begin
                overlay_on = 1;
                R = pinkcarR; G = pinkcarG; B = pinkcarB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos10b) && (x_s < xpos10b + $signed(OBJ10_W)) &&
                 (y   >= OBJ10_Y) && (y   < OBJ10_Y + OBJ10_H)) begin
            dx1  = x_s - xpos10b;
            texX = dx1[4:0];
            if (sprite_nonzero(pinkcarR, pinkcarG, pinkcarB)) begin
                overlay_on = 1;
                R = pinkcarR; G = pinkcarG; B = pinkcarB;
            end
        end
        else if (!overlay_on &&
                 (x_s >= xpos10c) && (x_s < xpos10c + $signed(OBJ10_W)) &&
                 (y   >= OBJ10_Y) && (y   < OBJ10_Y + OBJ10_H)) begin
            dx1  = x_s - xpos10c;
            texX = dx1[4:0];
            if (sprite_nonzero(pinkcarR, pinkcarG, pinkcarB)) begin
                overlay_on = 1;
                R = pinkcarR; G = pinkcarG; B = pinkcarB;
            end
        end
    end

    //-----------------------------------------------------------
    // POSITION OUTPUTS (one representative per row)
    //-----------------------------------------------------------
    always @* begin
        log_thickness = {
            OBJ5_W,  OBJ4_W, OBJ3_W, OBJ2_W, OBJ1_W,
            OBJ5_W,  OBJ4_W, OBJ3_W, OBJ2_W, OBJ1_W,
            OBJ5_W, OBJ5_W,OBJ5_W, OBJ4_W, OBJ2_W, OBJ2_W, OBJ1_W
        };
        
        car_thickness = {
            OBJ10_W, OBJ9_W, OBJ8_W, OBJ7_W, OBJ6_W,
            OBJ10_W, OBJ9_W, OBJ8_W, OBJ7_W, OBJ6_W,
            OBJ10_W, OBJ9_W, OBJ8_W, OBJ7_W
        };

        // export only the "a" object of each row
        car_x_pos = {
            xpos10a[9:0], xpos9a[9:0], xpos8a[9:0], xpos7a[9:0], xpos6a[9:0],
            xpos10b[9:0], xpos9b[9:0], xpos8b[9:0], xpos7b[9:0], xpos6b[9:0],
            xpos10c[9:0], xpos9c[9:0], xpos8c[9:0], xpos7c[9:0]
        };
        
        log_x_pos = {
            xpos5a[9:0],  xpos4a[9:0], xpos3a[9:0], xpos2a[9:0], xpos1a[9:0],
            xpos5b[9:0],  xpos4b[9:0], xpos3b[9:0], xpos2b[9:0], xpos1b[9:0],
            xpos5c[9:0], xpos5d[9:0],xpos5e[9:0], xpos4c[9:0], xpos2c[9:0],xpos2d[9:0], xpos1c[9:0]
        };

        car_y_pos = {
            OBJ10_Y[8:0], OBJ9_Y[8:0], OBJ8_Y[8:0], OBJ7_Y[8:0], OBJ6_Y[8:0],
            OBJ10_Y[8:0], OBJ9_Y[8:0], OBJ8_Y[8:0], OBJ7_Y[8:0], OBJ6_Y[8:0],
            OBJ10_Y[8:0], OBJ9_Y[8:0], OBJ8_Y[8:0], OBJ7_Y[8:0]
            
        };
        
        log_y_pos = {
            OBJ5_Y[8:0],  OBJ4_Y[8:0], OBJ3_Y[8:0], OBJ2_Y[8:0], OBJ1_Y[8:0],
            OBJ5_Y[8:0],  OBJ4_Y[8:0], OBJ3_Y[8:0], OBJ2_Y[8:0], OBJ1_Y[8:0],
            OBJ5_Y[8:0],  OBJ5_Y[8:0], OBJ5_Y[8:0], OBJ4_Y[8:0], OBJ2_Y[8:0], OBJ2_Y[8:0], OBJ1_Y[8:0]
        };
        
        spacing = {
            OBJ10_GAP, OBJ9_GAP, OBJ8_GAP, OBJ7_GAP, OBJ6_GAP,
            OBJ5_GAP, OBJ4_GAP, OBJ3_GAP, OBJ2_GAP, OBJ1_GAP
        };
    end

endmodule
