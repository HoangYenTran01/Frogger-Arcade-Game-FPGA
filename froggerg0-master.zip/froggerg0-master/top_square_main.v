`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////
// top_square_main
// Instantiates animation controller + top_square
//////////////////////////////////////////////////////////////

module top_square_main(
    input  wire CLK,
    input  wire RST_BTN,
    input [3:0] button_in,
    output wire VGA_HS_O,
    output wire VGA_VS_O,
    output wire [3:0] VGA_R,
    output wire [3:0] VGA_G,
    output wire [3:0] VGA_B
);
    wire [7:0] random_num;
    wire [7:0] hit;
    
   wire [2:0] count5;
    wire [2:0] count3;
    
    wire [9:0] frogx;
    wire [8:0] frogy;
    
    wire clk1hz;
    
   wire [139:0] car_x_pos,  car_thickness;
   wire [169:0] log_x_pos,  log_thickness;
   wire [125:0] car_y_pos;
   wire [152:0] log_y_pos;
   
   
   wire [15:0] bcd_score;
   wire [15:0] timecountdown;
   wire [15:0] bcdtimer;
   wire [2:0] lives;
   wire [4:0] prev_frogs;
   wire [3:0] frog_orientation;
   
   //RESET//
   wire [2:0] startnumber;
   wire [2:0] intructional_display;
   wire timeout;
   
   wire countdown5_done, countdown3_done, count5_enable, count3_enable;
wire enable_overlay;
wire diesignal;
wire startgame;
//   wire [3:0] countdowncheck;
   assign startgame = (frog_orientation == 0)? 1'b0 : 1'b1;
   
   orientation calc_ori (.clk(CLK), .reset(~countdown3_done), .button(button_in), .orientation(frog_orientation));
   

    // Animation controller (your existing one)
    square_anim_controller anim_inst (
        .CLK       (CLK),
        .RST_BTN   (RST_BTN),
        .random_num(random_num),
        .hit       (hit)
    );

    // VGA drawing + overlay
    top_square square_inst (
        .CLK      (CLK),
        .RST_BTN  (RST_BTN),
        .random_num(random_num),
        .hit      (hit),
        .VGA_HS_O (VGA_HS_O),
        .VGA_VS_O (VGA_VS_O),
        .VGA_R    (VGA_R),
        .VGA_G    (VGA_G),
        .VGA_B    (VGA_B),
         .car_x_pos(car_x_pos), 
         .log_x_pos(log_x_pos), 
         .car_y_pos(car_y_pos),
         .log_y_pos(log_y_pos),
         .log_thickness(log_thickness),
         .car_thickness(car_thickness),
         .frog_pos_x(frogx),
         .frog_pos_y(frogy),
         .bcd_score(bcd_score),
         .lives(lives),
         .lp_isOccupied(prev_frogs),
         .bcdtimer(bcdtimer),
         .instructions(intructional_display),
         .enable(enable_overlay),
         .frog_orientation(frog_orientation)
    );
    
        //========================================================
    // game logic
    //========================================================
    
    belowrivermerge game (.clk(CLK),
    .reset(~enable_overlay),
    .movement(button_in),
    .bcd_score(bcd_score),
     .lives(lives),
     .log_pos({log_y_pos, log_x_pos}),
     .car_pos({car_y_pos, car_x_pos}),
     .log_size(log_thickness),
     .car_size(car_thickness),
     .frog_x_current(frogx),
     .frog_y_current(frogy),
     .collision(collision),
     .prev_frogs(prev_frogs),
     .frog_orientation());
     
   
     
//    input clk1hz;
//    input global_reset;
//    output reg [3:0] count = 4'd7;
//    output reg enablegame; //start game when the output is 0
//// GAME START THROUGH USER RESET
     clock_divider #(.FREQ(1))
     onehzclk (.clk(CLK), .reset(RST_BTN), .divided_clk(clk1hz));
     
     assign diesignal = (lives== 0) ? 1'b0: 
                         (timeout == 1)? 1'b0 : 
                         (prev_frogs == 5'b11111) ? 1'b0:1'b1;
//     countdown displaycount(.clk1hz(clk1hz),.global_reset(RST_BTN), .count(count), .enablegame(enablegame));
//// TIMER COUNTDOWN
     countdown #(30) displaytime(.clk1hz(clk1hz),.global_reset(~enable_overlay),.count(timecountdown), .enable(timeout));
     to_bcd_score (.bin({6'b00000, timecountdown}), .bcd(bcdtimer));
//    parameter countdown = 3'd5, displaytime = 3'd3, waitdisplay = 3'd0; //START NUMBER
//    //display type;
//    parameter countstart = 3'd5, gameover = 3'b111, intro = 3'b110;
//    input clk;
//    input globalreset;
//    input startgame;
//    input diesignal;
//    input [3:0] count;
//    output reg [2:0] startnumber;
//    output reg [2:0] intructional_display;
//    output reg localreset; //for display

     processgamesignal resetprocess(.clk(CLK),.globalreset(RST_BTN), .startgame(startgame), .diesignal(diesignal), 
     .count5(count5), .count3(count3), .startnumber(startnumber), .countdown5_done(countdown5_done), .countdown3_done(countdown3_done), 
     .count5_enable(count5_enable), .count3_enable(count3_enable), .enable_overlay(enable_overlay), .intructional_display(intructional_display));
//    parameter countnumber = 4'd5;
//    parameter countbits = $clog2(countnumber);
//    parameter intructiontype = 3'b111; //death
//    input clk1hz;

//    input global_reset;
//    output reg [countbits:0] count = countnumber;
//    output reg enablegame; //start game when the output is 0
    countdown #(.countnumber(5)) countoption5 (.clk1hz(clk1hz), .global_reset(count5_enable),.count(count5), .enable(countdown5_done));
    countdown #(.countnumber(3)) countoption3 (.clk1hz(clk1hz), .global_reset(count3_enable),.count(count3), .enable(countdown3_done));
     
     

endmodule
