`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 01:35:20 PM
// Design Name: 
// Module Name: top_test
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module top_test(

    );

  reg clk, reset;
  // positions in {..., ypos1, y-pos0, ..., xpos1, xpos0}
  reg [3-1:0] car_pos_x1;
  reg [3-1:0] car_pos_y1;
  reg [3-1:0] car_pos_x2;
  reg [3-1:0] car_pos_y2;
  reg [3-1:0] log_pos_x1;
  reg [3-1:0] log_pos_y1;
  reg [3-1:0] log_pos_x2;
  reg [3-1:0] log_pos_y2;
  // sizes in {..., obj1height, obj0height, ..., obj1width, obj0width}
  reg [(2+2)-1:0] log_size1;
  reg [(2+2)-1:0] log_size2;
  reg [(2+2)-1:0] car_size1;
  reg [(2+2)-1:0] car_size2;
  // frog position in {frogpos_y, frogpos_x}
  reg [3+3-1:0] frog_pos;
  wire [1:0] collision_type;  // type of collsion to movement module
  // each grid position has a 3-bit object type
  
  
  collision_detect #(
  .X_BITS(3),
   .Y_BITS(3),
   .LOG_NUMBER(2),
   .CAR_NUMBER(2),
   .SCREEN_WIDTH(5), 
   .SCREEN_HEIGHT(6),
   .MAX_OBJ_WIDTH_BITS(2),
   .MAX_OBJ_HEIGHT_BITS(2),
    .WATER_ZONE_START(1),
  .WATER_ZONE_END(2),
  .ROAD_ZONE_START(4),
  .ROAD_ZONE_END(5)
   ) 
   
   dut (
  .clk(clk),
  .log_pos({log_pos_y2, log_pos_y1, log_pos_x2, log_pos_x1}), 
  .car_size({car_size2, car_size1}),
  .log_size({log_size2, log_size1}),
  .car_pos({car_pos_y2, car_pos_y1, car_pos_x2, car_pos_x1}),
  .frog_pos(frog_pos),
  .collision_type(collision_type)
  );
  
initial begin
  clk <= 1'b0;
  reset <= 1'b0;
  car_size1 <= {2'b01, 2'b10};
  car_pos_x1 <= 3'b000;
  car_pos_y1 <= 3'b100;
  
  car_size2 <= {2'b01,2'b01};
  car_pos_x2 <= 3'b011;
  car_pos_y2 <= 3'b011;
  
  log_size1 <= {2'b01,2'b10};
  log_pos_x1 <= 3'b000;
  log_pos_y1 <= 3'b001;
  
  log_size2 <= {2'b01,2'b01};
  log_pos_x2 <= 3'b011;
  log_pos_y2 <= 3'b010;
  
  
  frog_pos <= 6'b000000;
  #10 reset <= 1'b1;
  
  end
  
  always begin
    #10 clk <= ~clk;
  end

  always begin
      #40 frog_pos <= frog_pos + 1;
  end
  
endmodule
