`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 01:21:17 AM
// Design Name: 
// Module Name: digitDisplay
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module digitDisplay(
    input [3:0] x,
    input [3:0] y,
    input [3:0] bcdDigit,
    output reg [3:0] R,
    output reg [3:0] G,
    output reg [3:0] B
    );
    
    
    reg[11:0] zero [0:255];
    reg[11:0] one [0:255];
    reg[11:0] two [0:255];
    reg[11:0] three [0:255];
    reg[11:0] four [0:255];
    reg[11:0] five [0:255];
    reg[11:0] six [0:255];
    reg[11:0] seven [0:255];
    reg[11:0] eight [0:255];
    reg[11:0] nine [0:255];
    
    
    initial begin  
    
    $readmemh("zero.mem", zero);
    $readmemh("one.mem", one);
    $readmemh("two.mem", two);
    $readmemh("three.mem", three);
    $readmemh("four.mem", four);
    $readmemh("five.mem", five);
    $readmemh("six.mem", six);
    $readmemh("seven.mem", seven);
    $readmemh("eight.mem", eight);
    $readmemh("nine.mem", nine);
    
    end
    
    wire [9:0] pos;
    assign pos = x + y * 16;
    
    always @(*) begin
        
        case (bcdDigit)
        4'd0: begin R = zero[pos][11:8]; G = zero[pos][7:4]; B = zero[pos][3:0]; end
        4'd1: begin R = one[pos][11:8]; G = one[pos][7:4]; B = one[pos][3:0]; end
        4'd2: begin R = two[pos][11:8]; G = two[pos][7:4]; B = two[pos][3:0]; end
        4'd3: begin R = three[pos][11:8]; G = three[pos][7:4]; B = three[pos][3:0]; end
        4'd4: begin R = four[pos][11:8]; G = four[pos][7:4]; B = four[pos][3:0]; end
        4'd5: begin R = five[pos][11:8]; G = five[pos][7:4]; B = five[pos][3:0]; end
        4'd6: begin R = six[pos][11:8]; G = six[pos][7:4]; B = six[pos][3:0]; end
        4'd7: begin R = seven[pos][11:8]; G = seven[pos][7:4]; B = seven[pos][3:0]; end
        4'd8: begin R = eight[pos][11:8]; G = eight[pos][7:4]; B = eight[pos][3:0]; end
        4'd9: begin R = nine[pos][11:8]; G = nine[pos][7:4]; B = nine[pos][3:0]; end
        
        endcase
            
 
    end 
    
endmodule