`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/07/2025 07:31:49 PM
// Design Name: 
// Module Name: processgamesignal
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module processgamesignal(clk, globalreset, startgame, diesignal,count5,count3, startnumber, state, intructional_display, countdown5_done, countdown3_done, count5_enable, enable_overlay, count3_enable);
    parameter countdown = 3'd5, displaytime = 3'd3, waitdisplay = 3'd0; //START NUMBER
    //display type;
    parameter countstart = 3'd5, gameover = 3'b111, intro = 3'b110;
    input clk;
    input globalreset;
    input startgame;
    input diesignal;
    input countdown5_done;
    input countdown3_done;
    input [2:0] count5;
    input [2:0] count3;
    output reg [2:0] startnumber;
    output reg [2:0] intructional_display;
    output reg count5_enable, count3_enable;
    output reg enable_overlay;
    reg alreadydead;
//    output reg localreset; //for display
    wire clk1hz;
    
    parameter OFF = 3'b000 , INTRO = 3'b001, COUNT = 3'b010, GAME = 3'b011, DIE = 3'b100;
    output reg [2:0] state;
    always @ (posedge clk or negedge globalreset) begin
        if (globalreset == 0) begin
            state <= INTRO;
            count3_enable <= 0 ;
             count5_enable <= 0 ;
        end else begin
            if (state == COUNT) begin
            count3_enable <= 0;
                if (countdown5_done == 1) begin
                        enable_overlay <= 0;
                        state <= GAME;
                        count5_enable <= 0;
                        intructional_display <= count5;
                        
                end
                else begin 
                    enable_overlay <= 1;
                    state <= COUNT; 
                    count5_enable <= 1;
                    intructional_display <= count5;
                end
             end
            else if (state == INTRO) begin
            count3_enable <= 0;
                enable_overlay <= 1;
                intructional_display <= 3'b110;  // title 
                if (startgame == 1) begin
                        state <= COUNT;
                        count5_enable <= 1;
                end
                else begin
                    state <= INTRO;
                    count5_enable <= 0;
                end
            end
            else if (state == GAME) begin
            intructional_display <= 3'b110;
                if (diesignal == 0) begin
                    enable_overlay <= 1;
                    state <= DIE;
                    count3_enable <= 1;
                    count5_enable <= 0;
                end
                else begin
                enable_overlay <= 0;
                state <= GAME;
                count3_enable <= 0;
                  count5_enable <= 0;
                  
                end

            end
            else if (state == DIE) begin
                intructional_display <= 3'b111;  // game over
                count5_enable <= 0;
                
                if (countdown3_done==1)
                begin
                enable_overlay <= 0;
                    state <= INTRO;
                     count3_enable <= 0;
                     
                end
                else begin
                enable_overlay <= 1;
                    state <= DIE;
                    count3_enable <= 1;
                end
            end
            
            
           else begin
                state <= state;
            end
        end
        
           
        
                
    end

    always @(*) begin
    
     end
     

//        if (diesignal == 0) begin
//                alreadydead = 1'b0; 
//        end
//        case(state)
//            OFF: begin
//                if (globalreset == 1 && startgame == 1) begin
//                    next_state = COUNT;
//                end
//                else if (globalreset == 1 && startgame == 0) begin
//                    next_state = INTRO;
//                end
//            end
//            INTRO: begin
//                intructional_display = 3'b110; 
//                startnumber = 3'b110; 
//                if (startgame == 1) begin
//                    next_state = COUNT;
//                end
                
//            end
//            COUNT: begin
//                intructional_display = 3'b101; 
//                startnumber = 3'b101; 
//                if (count == 0) begin
//                    next_state = GAME;
//                end
//            end
//            GAME: begin
//                intructional_display = 3'b000; 
//                startnumber = 0; 
//                if (alreadydead == 1'b1) begin
//                    next_state = DIE;
//                end
//            end
//            DIE:  begin
//                intructional_display = 3'b111; 
//                startnumber = 3'b011; 
//                if (count == 0) begin
//                    next_state = GAME;
//                end
//            end
//            default: begin
//                next_state = INTRO;
//            end
//        endcase    
//    end

    
endmodule

//    always @(posedge startgame or negedge globalreset) begin
//        if (globalreset == 1'b1 && startgame == 1'b1) begin
//        //Start counting down -> passing what into the countdown module -> enabling countdown module
//        //Pass in parameter for acount down
//        //Enable separate signal for just display the motion  
//            intructional_display <=  countstart;
//            startnumber <= countdown;                 
//        end
//        else if (globalreset == 1'b1 && startgame == 1'b0) begin
//        //keep it running and dont count down -> spam input 3'b110
//            intructional_display <= intro;
//            startnumber <= waitdisplay;
//        end
//        else if (diesignal == 1) begin
//            intructional_display = gameover;   
//            startnumber <= displaytime;
//        end
//    end
