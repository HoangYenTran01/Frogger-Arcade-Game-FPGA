`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/06/2025 01:40:37 AM
// Design Name: 
// Module Name: pinkcar
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pinkcar(
    input [4:0] x,
    input [4:0] y,
    output [3:0] R,
    output [3:0] G,
    output [3:0] B
    );
    
    
    reg[11:0] log [0:1023];
    initial $readmemh("pinkcar.mem", log);
    
    wire [9:0] pos;
    assign pos = x + y * 32;
    
    assign R = log[pos][11:8];
    assign G = log[pos][7:4];
    assign B = log[pos][3:0];
    
    
endmodule