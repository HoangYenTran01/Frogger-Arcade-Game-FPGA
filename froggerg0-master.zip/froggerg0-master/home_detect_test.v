`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 01:15:42 PM
// Design Name: 
// Module Name: home_detect_test
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module home_detect_test(

    );
    
    reg clk, reset;
      reg [9:0] frog_posx;
  reg [4:0] prev_frogs;
 wire [1:0] home;
 wire [4:0] home_touch;
 
  home_detect #(
      .SCREEN_WIDTH(64),
      .MARGIN_SIZE(10),
      .X_BITS(10)
  ) dut (
      .clk(clk),
      .reset(reset),
      .frog_posx(frog_posx),
      .prev_frogs(prev_frogs),
      .home(home),
      .home_touch(home_touch)
  );
  
  
    
  initial begin
  clk <= 1'b0;
  reset <= 1'b0;
  frog_posx <= 0;
  prev_frogs <= 5'b01010;
  #20 reset <= 1'b1;
  
  end
  
  always begin
    #10 clk <= ~clk;

  end
 always begin 
     #40 frog_posx <= frog_posx + 1;
 end

 
endmodule
