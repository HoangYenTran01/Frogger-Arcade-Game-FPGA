// records the positions of previous frogs

module prev_frog (
    clk,  // we can feed the clock with the output of home_detect module
    reset,
    new_frog, // location of incoming frog, in terms of home numbering
    prev_frog
);

  parameter SCREEN_WIDTH = 40;
  parameter X_BITS = $clog2(SCREEN_WIDTH);
parameter HOME_NUMBER = 5;

  input clk, reset;
  input [HOME_NUMBER-1:0] new_frog;
  output reg [HOME_NUMBER-1:0] prev_frog;  // the top row, 1 if there is prev frog on position


  always @(posedge clk) begin
    if (reset == 1'b0) begin
      prev_frog <= 0;
    end else begin
     prev_frog <= prev_frog | new_frog;
    end
  end
endmodule
