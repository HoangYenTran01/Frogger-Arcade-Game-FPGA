`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/06/2025 02:59:31 AM
// Design Name: 
// Module Name: twoDigitCtr
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module twoDigitCtr(
    input [5:0] x,
    input [3:0] y,
    input [7:0] bcdDigit,
    output reg [3:0] R,
    output reg [3:0] G,
    output reg [3:0] B
    );
    
    wire[3:0] tex_x = x % 16;
    
    wire [3:0] dd1R, dd1G, dd1B;
    wire [3:0] dd2R, dd2G, dd2B;
    
    digitDisplay dd1(
    .x(tex_x),
    .y(y),
    .bcdDigit(bcdDigit[7:4]),
    .R(dd1R),
    .G(dd1G),
    .B(dd1B)
    );
    
    digitDisplay dd2(
    .x(tex_x),
    .y(y),
    .bcdDigit(bcdDigit[3:0]),
    .R(dd2R),
    .G(dd2G),
    .B(dd2B)
    );
    
    
    wire val2Print;
    assign val2Print = x >> 4;
    
    always @(*) begin
        case (val2Print)
            1'b0:begin R = dd1R; G = dd1G; B = dd1B; end
            1'b1:begin R = dd2R; G = dd2G; B = dd2B; end
        endcase
    end
    
    
    
    
    
    endmodule