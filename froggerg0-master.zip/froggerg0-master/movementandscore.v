`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/01/2025 10:09:29 PM
// Design Name: 
// Module Name: movementandscore
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: Frog movement, score, lives, and interaction with logs
// 
//////////////////////////////////////////////////////////////////////////////////


module movementandscore(
    input  wire        start_game,
    input  wire        clk,
    input  wire        reset,
    input  wire [1:0]  collisiontype,
    input  wire [3:0]  movement,
    input  wire        on_log,          // currently unused
    input  wire signed [4:0] logspeed,  // UNUSED now; internal eff_logspeed used instead

    output reg  [11:0] score = 12'd0,
    output reg  [$clog2(lives_num)-1:0] lives,
    output reg  [Y_BITS-1:0] frog_y_current,
    output reg  [X_BITS-1:0] frog_x_current,
    output reg               checksignal,
    output [3:0] frog_orientation
//    output reg local_reset
);

    // Collision types
    parameter [1:0] DEATH   = 2'b01,
                    HOME    = 2'b10,
                    NOTHING = 2'b00;

    parameter numberofhome   = 5;
    parameter x_min          = 2;
    parameter x_max          = 607;
    parameter y_min          = 0;
    parameter y_max          = 415; // highest point has y = 0

    parameter frog_to_go_home = 5;
    parameter STEP_Y          = 32;
    parameter STEP_X          = 32; // tiles are 32x32

    // Original position (grid coordinates)
    parameter y_origin = 6'd15;
    parameter x_origin = 6'd10;

    // Lives
    parameter lives_num = 3'd6;

    // Bit widths for positions
    parameter X_BITS = $clog2(x_max);      // enough bits for 0..x_max
    parameter Y_BITS = $clog2(y_max + 1);  // enough bits for 0..y_max (avoid clog2(0))

    // Processed movement buttons (debounced etc.)
    wire [3:0] processedsignal;
    wire up, right, left, down;

    // Next-state registers
    reg [Y_BITS-1:0] frog_y_next;
    reg [X_BITS-1:0] frog_x_next;

    reg [Y_BITS-1:0] current_max_y_pos        = y_origin;
    reg [Y_BITS-1:0] current_max_y_pos_next;

    reg [2:0] frog_left                       = frog_to_go_home;
    reg [2:0] frog_left_next                  = numberofhome;

    reg [11:0] score_next                     = 12'd0;
    reg [$clog2(lives_num)-1:0] lives_next;
    reg                      checksignal_next;

    // Signed intermediates for log motion
    reg signed [X_BITS:0] frog_x_with_log;
    reg signed [X_BITS:0] frog_x_left_with_log;
    reg signed [X_BITS:0] frog_x_right_with_log;

    // Internal effective logspeed based on lane (direction & magnitude)
    reg signed [4:0] eff_logspeed;       // combinational from frog_y_current
    reg signed [4:0] step_logspeed;      // actually applied on slow steps

    // Divider for slow horizontal movement (like original 5_000_000)
    reg [$clog2(5000000)-1:0] log_cnt;
    reg [$clog2(500000)-1:0] home_cnt;

    // Instantiate processed IO for movement
    processedIO processmovement(
        .clk(clk),
        .reset(reset),
        .movement(movement),
        .processedsignal(processedsignal)
    );

    assign up    = processedsignal[0];
    assign right = processedsignal[1];
    assign left  = processedsignal[2];
    assign down  = processedsignal[3];
    
    assign frog_orientation = processedsignal;

    /////////////////////////////////////////////////
    // EFFECTIVE LOG SPEED PER LANE (COMBINATIONAL)
    /////////////////////////////////////////////////
    always @(*) begin
        // Default: no drift
        eff_logspeed = 0;

        // Choose drift based on frog_y_current row
        // NOTE: these match your frogspeedwithlog rows,
        // but now they are always correct for the current lane.
        if      (frog_y_current == 9'd63)  eff_logspeed =  3;   // right
        else if (frog_y_current == 9'd95)  eff_logspeed = -3;   // left
        else if (frog_y_current == 9'd127) eff_logspeed = 4;   // left (FIXED)
        else if (frog_y_current == 9'd159) eff_logspeed =  2;   // right
        else if (frog_y_current == 9'd191) eff_logspeed = -3;   // left
        // else: stays 0
    end

    /////////////////////////////////////////////////
    // SLOW STEP GENERATOR FOR LOG DRIFT (SEQUENTIAL)
    // - Every ~5_000_000 cycles, apply eff_logspeed
    // - Otherwise, no horizontal drift from logs
    /////////////////////////////////////////////////
    always @(posedge clk or negedge reset) begin
        if (!reset) begin
            log_cnt       <= 0;
            step_logspeed <= 0;
        end else begin
            if (log_cnt == 5000000-1) begin
                log_cnt       <= 0;
                step_logspeed <= eff_logspeed;   // one slow "tick" with lane-based speed
            end else begin
                log_cnt       <= log_cnt + 1;
                step_logspeed <= 0;              // no drift between ticks
            end
        end
    end

    /////////////////////////////////////////////////
    // SEQUENTIAL LOGIC (state updates)
    /////////////////////////////////////////////////
    always @(posedge clk or negedge reset) begin
        if (reset == 1'b0) begin
            frog_y_current      <= y_origin;
            frog_x_current      <= x_origin;
            frog_left           <= frog_to_go_home;
            score               <= 12'd0;
            lives               <= lives_num;
            current_max_y_pos   <= y_origin;
            checksignal         <= 1'b0;
        end
        else begin
            frog_y_current      <= frog_y_next;
            frog_x_current      <= frog_x_next;
            score               <= score_next;
            lives               <= lives_next;
            frog_left           <= frog_left_next;
            current_max_y_pos   <= current_max_y_pos_next;
            checksignal         <= checksignal_next;
        end
    end

    /////////////////////////////////////////////////
    // COMBINATIONAL LOGIC (next state + movement)
    /////////////////////////////////////////////////
    always @(*) begin
        // Default: hold state
//        frog_y_next            = frog_y_current;
//        frog_x_next            = frog_x_current;
//        score_next             = score;
//        lives_next             = lives;
//        frog_left_next         = frog_left;
//        current_max_y_pos_next = current_max_y_pos;
//        checksignal_next       = checksignal;

        // Signed intermediates for log motion, using *step_logspeed*
        frog_x_with_log       = $signed({1'b0, frog_x_current}) + $signed(step_logspeed);
        frog_x_left_with_log  = $signed({1'b0, (frog_x_current - STEP_X)}) + $signed(step_logspeed);
        frog_x_right_with_log = $signed({1'b0, (frog_x_current + STEP_X)}) + $signed(step_logspeed);

        case (collisiontype)
            /////////////////////////////////////////
            // DEATH: lose a life, reset frog
            /////////////////////////////////////////
            DEATH: begin
                if (lives > 0) begin
                    lives_next = lives - 1;
//                    if (lives == 1) begin
                        
//                    end
                end

                    frog_y_next            = y_origin;
                    frog_x_next            = x_origin;
                    current_max_y_pos_next = y_origin;
                    checksignal_next       = 1'b0;
            end

            /////////////////////////////////////////
            // HOME: gained a home, score +100
            /////////////////////////////////////////
            HOME: begin                
                    score_next             = score + 12'd100;
                    frog_y_next            = y_origin;
                    frog_x_next            = x_origin;
                    current_max_y_pos_next = y_origin;
                    checksignal_next       = 1'b1;
            end

            /////////////////////////////////////////
            // NOTHING: normal movement + logs
            /////////////////////////////////////////
            NOTHING: begin
                frog_y_next            = frog_y_current;
                frog_x_next            = frog_x_current;
                score_next             = score;
                lives_next             = lives;
                frog_left_next         = frog_left;
                current_max_y_pos_next = current_max_y_pos;

                // Baseline: drift with log if any (step_logspeed may be 0)
                checksignal_next       = 1'b1;
                //reset number of lives and and reset countdown
                if (lives == 0) begin
                    lives_next = lives_num;
                    checksignal_next = 1'b0;
                end
                if (frog_x_with_log < x_min)
                    frog_x_next = x_min;
                else if (frog_x_with_log > x_max)
                    frog_x_next = x_max;
                else
                    frog_x_next = frog_x_with_log[X_BITS-1:0];

                // UP
                if ((up == 1'b1) && (frog_y_current > y_min)) begin
                    frog_y_next = frog_y_current - STEP_Y;

                    // Progress upward → bonus score
                    if (current_max_y_pos > (frog_y_current - STEP_Y)) begin
                        current_max_y_pos_next = frog_y_current - STEP_Y;
                        score_next             = score + 12'd10;
                    end
                end

                // LEFT
                if (left == 1'b1) begin
                    if (frog_x_current > x_min) begin
                        // One hop left plus step_logspeed
                        if (frog_x_left_with_log < x_min)
                            frog_x_next = x_min;
                        else
                            frog_x_next = frog_x_left_with_log[X_BITS-1:0];
                    end
                    else begin
                        // At left wall: just drift with log
                        if (frog_x_with_log < x_min)
                            frog_x_next = x_min;
                        else
                            frog_x_next = frog_x_with_log[X_BITS-1:0];
                    end
                end

                // RIGHT
                if (right == 1'b1) begin
                    if (frog_x_current < x_max) begin
                        // One hop right plus step_logspeed
                        if (frog_x_right_with_log > x_max)
                            frog_x_next = x_max;
                        else
                            frog_x_next = frog_x_right_with_log[X_BITS-1:0];
                    end
                    else begin
                        // At right wall: just drift with log
                        if (frog_x_with_log > x_max)
                            frog_x_next = x_max;
                        else
                            frog_x_next = frog_x_with_log[X_BITS-1:0];
                    end
                end

                // DOWN
                if ((down == 1'b1) && (frog_y_current < y_max)) begin
                    frog_y_next = frog_y_current + STEP_Y;
                    // X already handled by log drift above
                end
            end

            default: begin
                // keep defaults
            end
        endcase
    end

endmodule
