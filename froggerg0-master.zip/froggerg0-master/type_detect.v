module type_detect (
    collision_type,
    clk,
    reset,
    road_die,
    water_die,
    zone,
    grass_die
);


  parameter [1:0] DEATH = 2'b01, HOME = 2'b10, NOTHING = 2'b00;  // collision types
  parameter [1:0] ROAD = 2'b01, WATER = 2'b10, GRASS = 2'b11, SAFE = 2'b00;
  input clk, reset;
  input road_die, water_die;  // whether the frog dies in road/water region
  input [1:0] grass_die;  // nothing=00, death=10, home=01
  input [1:0] zone;
  output reg [1:0] collision_type;  // type of collsion to movement module


  always @(posedge clk) begin
    if (reset == 1'b0) collision_type <= NOTHING;
    else begin
      case (zone)
        SAFE:  collision_type <= NOTHING;
        ROAD:  collision_type <= (road_die == 0) ? NOTHING : DEATH;
        WATER: collision_type <= (water_die == 0) ? NOTHING : DEATH;
        GRASS: collision_type <= (grass_die == 0) ? NOTHING : (grass_die == 2'b01) ? HOME : DEATH;
      endcase
    end
  end

endmodule
