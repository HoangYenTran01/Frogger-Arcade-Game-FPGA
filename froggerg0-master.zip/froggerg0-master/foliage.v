`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/01/2025 11:57:49 PM
// Design Name: 
// Module Name: foliage
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/01/2025 08:23:23 PM
// Design Name: 
// Module Name: frog
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module foliage(
    input [4:0] x,
    input [4:0] y,
    output [3:0] R,
    output [3:0] G,
    output [3:0] B
    );
    
    
    reg[11:0] foliage [0:1023];
    initial $readmemh("foliage.mem", foliage);
    
    wire [9:0] pos;
    assign pos = x + y * 32;
    
    assign R = foliage[pos][11:8];
    assign G = foliage[pos][7:4];
    assign B = foliage[pos][3:0];
    
    
endmodule

