`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/08/2025 09:44:51 PM
// Design Name: 
// Module Name: orientation
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module orientation (
    input [3:0] button,
    input clk,
    input reset,
    output reg [3:0] orientation
);

  wire [3:0] button_in;
  genvar button_i;
  generate
    for (button_i = 0; button_i < 4; button_i = button_i + 1) begin
      debouncer deb (
          .clk(clk),
          .reset(reset),
          .insignal(button[button_i]),
          .outsignal(button_in[button_i])
      );
    end
  endgenerate

  always @(posedge clk) begin
    if (reset == 0) begin
      orientation <= 4'b0000;  // default up
    end else begin
      if (button_in[0] == 1) begin
        orientation <= 4'b0001;
      end else if (button_in[1] == 1) begin
        orientation <= 4'b0010;
      end else if (button_in[2] == 1) begin
        orientation <= 4'b0100;
      end else if (button_in[3] == 1) begin
        orientation <= 4'b1000;
      end else begin
        orientation <= orientation;
      end
    end
  end
endmodule
