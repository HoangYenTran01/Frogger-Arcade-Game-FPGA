`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/06/2025 06:15:56 PM
// Design Name: 
// Module Name: lives_decoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module lives_decoder(bin, screen
    );
    input [2:0] bin;
    output reg [2:0] screen;
    
    always @(*) begin
        case(bin)
        3'b000: screen <= 3'b000;
        3'b001: screen <= 3'b001;
        3'b010: screen <= 3'b001;
        3'b011: screen <= 3'b011;
        3'b100: screen <= 3'b011;
        3'b101: screen <= 3'b111;
        3'b110: screen <= 3'b111;
//        2'b00: screen <= 3'b000;
//        2'b01: screen <= 3'b100;
//        2'b10: screen <= 3'b110;
//        2'b11: screen <= 3'b111;
        endcase
    end
endmodule
