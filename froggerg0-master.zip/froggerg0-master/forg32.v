`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 03:55:50 PM
// Design Name: 
// Module Name: forg32
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module forg32(
    input [4:0] x,
    input [4:0] y,
    input [3:0] orientation,
    output reg [3:0] R,
    output reg [3:0] G,
    output reg [3:0] B
    );
    
    
    reg[11:0] log [0:1023];
    initial $readmemh("forg32.mem", log);
    
    reg [9:0] pos;
    
    
    
    
    always @(*) begin
        case (orientation)
            4'b1000: pos = 1023 - (x + (y << 5));//facing down
            4'b0100: pos = (x << 5) + (31 - y);//facing left?
            4'b0010: pos = 1023 - (y + (x << 5));//facing right
            default: pos = x + (y << 5);//facing up
        endcase
    
        R = log[pos][11:8];
        G = log[pos][7:4];
        B = log[pos][3:0];
    end
    
    
endmodule