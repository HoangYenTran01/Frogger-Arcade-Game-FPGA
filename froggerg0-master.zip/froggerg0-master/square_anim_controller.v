`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////
// square_anim_controller
// Drives random_num + hit to animate boxes one-by-one
//////////////////////////////////////////////////////////////

module square_anim_controller (
    input  wire CLK,       // 100 MHz
    input  wire RST_BTN,   // active-low reset on Nexys4
    output reg  [7:0] random_num,
    output reg  [7:0] hit
);

    wire rst = ~RST_BTN;

    // animation timing (0.5s)
    localparam integer ANIM_MAX = 80_000_000;
    reg [25:0] anim_cnt;

    reg [2:0] idx;     // which box is animating 0..7
    reg       phase;   // 0 = red → yellow, 1 = yellow → green

    always @(posedge CLK or posedge rst) begin
        if (rst) begin
            random_num <= 8'b0;
            hit        <= 8'b0;
            anim_cnt   <= 0;
            idx        <= 0;
            phase      <= 0;
        end else begin
            if (anim_cnt == ANIM_MAX-1) begin
                anim_cnt <= 0;

                if (!phase) begin
                    // red → yellow
                    random_num[idx] <= 1'b1;
                    phase <= 1;
                end else begin
                    // yellow → green
                    random_num[idx] <= 1'b0;
                    hit[idx]        <= 1'b1;

                    phase <= 0;

                    // move to next box
                    if (idx == 3'd7)
                        idx <= 0;     // restart animation
                    else
                        idx <= idx + 1;
                end

            end else begin
                anim_cnt <= anim_cnt + 1;
            end
        end
    end

endmodule
