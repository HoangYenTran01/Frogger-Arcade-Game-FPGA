`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////
// line_color_controller (REVERSED ORDER, SCALED)
//////////////////////////////////////////////////////////////

module line_color_controller #(
    parameter NUM_LINES = 30
)(
    input  wire [NUM_LINES-1:0] line,
    input  wire [7:0]           random_num,
    input  wire [7:0]           hit,
    output reg  [3:0]           R,
    output reg  [3:0]           G,
    output reg  [3:0]           B,
    input  wire [9:0]           x,  // current pixel x position: 0-639
    input  wire [8:0]           y   // current pixel y position: 0-479
);

    localparam LINE_BITS = (NUM_LINES <= 2)   ? 1 :
                           (NUM_LINES <= 4)   ? 2 :
                           (NUM_LINES <= 8)   ? 3 :
                           (NUM_LINES <= 16)  ? 4 :
                           (NUM_LINES <= 32)  ? 5 : 6;

    localparam [LINE_BITS-1:0] NO_LINE = {LINE_BITS{1'b1}};

    integer i;
    reg [LINE_BITS-1:0] active_line;
    reg [3:0]           row14;

    // ---- FOLIAGE TEXTURE (for purple bands) ----
    wire [3:0] foliageR, foliageG, foliageB;
    wire [3:0] grassR, grassG, grassB;
    reg  [4:0] texX, texY;
    reg  [3:0] grassX, grassY;

    foliage f (
        .x (texX),
        .y (texY),
        .R (foliageR),
        .G (foliageG),
        .B (foliageB)
    );
    
    grass g (
        .x (grassX),
        .y (grassY),
        .R (grassR),
        .G (grassG),
        .B (grassB)
        );

    // soften / purple-bias the foliage, but keep the texture
    wire [3:0] folR_soft;
    wire [3:0] folG_soft;
    wire [3:0] folB_soft;

    assign folR_soft = (foliageR >> 1) + 4'd4;  // add a little red
    assign folG_soft =  foliageG >> 2;          // reduce green
    assign folB_soft = (foliageB >> 1) + 4'd4;  // add some blue

    always @* begin
        // texture coordinates for foliage (32x32 tile)
        texX = x[4:0];       // x % 32
        texY = y[4:0];       // y % 32
        
        grassX = x[3:0];     // x % 16
        grassY = y[3:0];     // x % 16

        // -----------------------------------------
        // Find active physical line
        // -----------------------------------------
        active_line = NO_LINE;
        for (i = 0; i < NUM_LINES; i = i + 1)
            if (line[i])
                active_line = i[LINE_BITS-1:0];

        // defaults
        R     = 4'h0;
        G     = 4'h0;
        B     = 4'h0;
        row14 = 4'hF;

        if (active_line != NO_LINE) begin
            // -------------------------------------
            // Map physical line -> virtual row 0..13
            // -------------------------------------
            if (NUM_LINES == 14) begin
                row14 = active_line[3:0];
            end else begin
                row14 = (active_line * 14) / NUM_LINES;

                if (NUM_LINES == 30) begin
                    // TOP: force lines 0..3 to row 0 (thicker green)
                    if (active_line <= 3)
                        row14 = 4'd0;

                    // MIDDLE purple band adjustments
                    if (active_line == 14)
                        row14 = 4'd7;   // make 14 purple as well
                    if (active_line == 16 || active_line == 17)
                        row14 = 4'd8;   // move them out of purple band

                    // BOTTOM purple band
                    if ((active_line >= 26) && (active_line != 28) && (active_line != 29))
                        row14 = 4'd13;

                    if ((active_line == 28) || (active_line == 29))
                        row14 = 4'd8;
                end
            end

            // -------------------------------------
            // ORIGINAL 14-LINE COLOR LOGIC (with textured purple)
            // -------------------------------------
            case (row14)
                // rows 13 & 7 -> textured purple (soft foliage)
                4'd13,
                4'd7: begin
                    R = folR_soft;
                    G = folG_soft;
                    B = folB_soft;
                end

                // 2..6 -> black
                4'd1, 4'd2, 4'd3, 4'd4, 4'd5, 4'd6: begin
                    R = 4'h3; G = 4'h4; B = 4'hC;
                end

                // 0 -> lime green
                4'd0: begin
                    R = grassR; G = grassG; B = grassB;
                end

                default: begin
                    R = 4'h0; G = 4'h0; B = 4'h0;
                end
            endcase
        end
    end

endmodule
