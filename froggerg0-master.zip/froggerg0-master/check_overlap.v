// check if frog coincide with gameobject specified by pos and obj_size
// the position is the point at the top left

module check_overlap (
    frog_pos_x,
    obj_pos_x,
    obj_size_x,
    frog_pos_y,
    obj_pos_y,
    obj_size_y,
    overlap
);
 parameter SCREEN_WIDTH = 640;
  parameter SCREEN_HEIGHT = 480;
  parameter X_BITS = $clog2(SCREEN_WIDTH);
  parameter Y_BITS = $clog2(SCREEN_HEIGHT);
  parameter MAX_OBJ_WIDTH_BITS = 10;
  parameter MAX_OBJ_HEIGHT_BITS = 6;
  parameter COLLISION_BOX_WIDTH = 32;
  parameter COLLISION_MARGIN = 10;



 input [X_BITS-1:0] frog_pos_x;  // top left corner coord

  input [Y_BITS-1:0] frog_pos_y;
  input [MAX_OBJ_HEIGHT_BITS-1:0] obj_size_y;
  input [MAX_OBJ_WIDTH_BITS-1:0] obj_size_x;
  input [Y_BITS-1:0] obj_pos_y;
  input [X_BITS-1:0] obj_pos_x;

  output reg overlap;
  
  wire [X_BITS-1:0] frog_pos_x__, cl_x;

assign frog_pos_x__ = frog_pos_x + COLLISION_BOX_WIDTH;
assign cl_x = frog_pos_x +COLLISION_MARGIN;

  always @(*) begin
  if (obj_pos_y <= frog_pos_y+COLLISION_MARGIN &&
        obj_pos_y+32> frog_pos_y + COLLISION_MARGIN)
        begin
    if (obj_pos_x <= frog_pos_x+ COLLISION_MARGIN&&
        frog_pos_x +COLLISION_MARGIN< obj_pos_x + obj_size_x) overlap <= 1'b1;
    else if (obj_pos_x <= frog_pos_x__-COLLISION_MARGIN &&
        frog_pos_x__ -COLLISION_MARGIN< obj_pos_x + obj_size_x)  overlap <= 1'b1;
    else overlap <= 1'b0;
    end
   else overlap <= 1'b0;

end

endmodule
