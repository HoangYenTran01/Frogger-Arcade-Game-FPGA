`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/04/2025 11:33:27 PM
// Design Name: 
// Module Name: checkfornegedge
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module checkfornegedge(clk, reset, signalin, signalout);
    input clk;
    input reset;
    input  signalin;
    output reg signalout;
    reg signalprev;
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            signalprev <= 0;
            signalout <= 0;
        end else begin
            signalout <= (signalprev == 1'b1 && signalin == 1'b0);
            signalprev <= signalin;
        end
    end
endmodule
