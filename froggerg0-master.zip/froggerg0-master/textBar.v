`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/04/2025 11:15:56 PM
// Design Name: 
// Module Name: textBar
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module textBar (


    output reg  [3:0]           R,
    output reg  [3:0]           G,
    output reg  [3:0]           B,
    input wire [9:0] x,  // current pixel x position: 0-639
    input wire [8:0] y,  // current pixel y position: 0-479
    input wire [15:0] bcd_score,
    input wire [2:0] enable_lives,
    input wire[4:0] isOccupied,
    input wire [15:0] bcdtimer
);
    wire [3:0] lbR, lbG, lbB;
    wire [3:0] stR, stG, stB;
    wire [3:0] ttR, ttG, ttB;
    wire [3:0] scoreR, scoreG, scoreB;
    wire [3:0] overlayR, overlayG, overlayB;
    wire [3:0] timeR, timeG, timeB;
    wire [3:0] padR [0:4], padG [0:4], padB[0:4];
    
    
    //provides the correct shifted output for each lily pad
    wire [5:0] pad_x [0:4];
    assign pad_x [0] = (x >= 32 && x < 96) ? (x - 32)  : 0;   
    assign pad_x [1] = (x >= 160 && x < 224) ? (x - 160)  : 0;  
    assign pad_x [2] = (x >= 288 && x < 352) ? (x - 288)  : 0;   
    assign pad_x [3] = (x >= 416 && x < 480) ? (x - 416)  : 0;   
    assign pad_x [4] = (x >= 544 && x < 608) ? (x - 544)  : 0; 
    
    wire [5:0] pad_y;
    
    assign pad_y = (y < 64) ? y[5:0] : 6'd0;
    
    lilypad lp1(.x(pad_x[0]), .y(pad_y), .R(padR[0]), .G(padG[0]), .B(padB[0]), .isOccupied(isOccupied[0]));
    lilypad lp2(.x(pad_x[1]), .y(pad_y), .R(padR[1]), .G(padG[1]), .B(padB[1]), .isOccupied(isOccupied[1]));
    lilypad lp3(.x(pad_x[2]), .y(pad_y), .R(padR[2]), .G(padG[2]), .B(padB[2]), .isOccupied(isOccupied[2]));
    lilypad lp4(.x(pad_x[3]), .y(pad_y), .R(padR[3]), .G(padG[3]), .B(padB[3]), .isOccupied(isOccupied[3]));
    lilypad lp5(.x(pad_x[4]), .y(pad_y), .R(padR[4]), .G(padG[4]), .B(padB[4]), .isOccupied(isOccupied[4]));
    
    wire [5:0] tex_x = (x >= 64 && x < 128) ? (x - 64)  : 0;   // 0-63
    wire [4:0] tex_y = (y >= 448 && y < 464) ? (y - 448) : 0;  // 0-15
    
    wire [5:0] time_tex_x = (x >= 512 && x < 576) ? (x - 512)  : 0;   // 0-63
    wire [5:0] time_digs_x = (x >= 576 && x < 608) ? (x - 576)  : 0;   // 0-63
    
    wire [4:0] time_tex_y = (y >= 448 && y < 464) ? (y - 448) : 0;  // 0-15
    
    wire [5:0] num_x = (x >= 128 && x < 192) ? (x - 128) : 0;   // 0-63
    
    lifeBar l (.R(lbR), .G(lbG), .B(lbB), .x(x), .y(y), .enable(enable_lives));
    scoretext st(.R(stR), .G(stG), .B(stB), .x(tex_x), .y(tex_y));
    timetext tt(.R(ttR), .G(ttG), .B(ttB), .x(time_tex_x), .y(time_tex_y));
    multiDigitDisplay mdd(.x(num_x), .y(tex_y), .R(scoreR), .G(scoreG), .B(scoreB), .bcdDigit(bcd_score));
    twoDigitCtr tdc(.x(time_digs_x), .y(time_tex_y), .R(timeR), .G(timeG), .B(timeB), .bcdDigit(bcdtimer));
    
    wire [5:0] scoreX;
    assign scoreX = x % 64;

    always @(*) begin
    
        if (y > 448 && x < 48 && y < 464) begin

                R = lbR; G = lbG; B =lbB;
                
                end else if (y >= 448 && y < 480 && x >= 64 && x < 128) begin
                    R = stR; G = stG; B = stB;
                end else if (y >= 448 && y < 480 && x >= 128 && x < 192) begin
                    R = scoreR; G = scoreG; B = scoreB;
                end else if (y >= 448 && y < 480 && x >= 512 && x < 576) begin
                    R = ttR; G = ttG; B = ttB;
                end else if (y >= 448 && y < 480 && x >= 576 && x < 608) begin
                    R = timeR; G = timeG; B = timeB;
                    //LILY PADS
                end else if (y >= 0 && y < 64 && x >= 32 && x < 96) begin
                    R = padR[0]; G = padG[0]; B = padB[0];
                    
                end else if (y >= 0 && y < 64 && x >= 160 && x < 224) begin
                    R = padR[1]; G = padG[1]; B = padB[1];
                end else if (y >= 0 && y < 64 && x >= 288 && x < 352) begin
                    R = padR[2]; G = padG[2]; B = padB[2];
                end else if (y >= 0 && y < 64 && x >= 416 && x < 480) begin
                    R = padR[3]; G = padG[3]; B = padB[3];
                end else if (y >= 0 && y < 64 && x >= 544 && x < 608) begin
                    R = padR[4]; G = padG[4]; B = padB[4];
                end else begin
                    R = 4'h0; G = 4'h0; B = 4'h0;
                end
    
    end
endmodule
