`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// top_square
// - Generates VGA timing
// - Creates 14 horizontal "lines" (strips)
// - Uses line_color_controller to color each line
// - Stacks decoration overlay on top
//////////////////////////////////////////////////////////////////////////////////

module top_square(
    input  wire CLK,             // board clock: 100 MHz
    input  wire RST_BTN,
    input  wire [7:0] random_num,
    input  wire [7:0] hit,
    input [9:0] frog_pos_x,
    input [8:0] frog_pos_y,
    input [15:0] bcd_score,
    input [15:0] bcdtimer,
    input [2:0] lives,
    input [4:0] lp_isOccupied,
    input [3:0] frog_orientation,
    output wire VGA_HS_O,
    output wire VGA_VS_O,
    output wire [3:0] VGA_R,
    output wire [3:0] VGA_G,
    output wire [3:0] VGA_B,
    output  [139:0] car_x_pos,  car_thickness,
    output  [169:0] log_x_pos,  log_thickness,
    //ENABLE SIGNAL FOR DISPLAY
    input wire [2:0] instructions,
    input wire enable,
    output  [125:0] car_y_pos, 
    output  [152:0] log_y_pos
);
    wire rst = ~RST_BTN;    // reset is active low on Nexys/Arty

    //========================================================
    // 25 MHz pixel strobe
    //========================================================
    reg [15:0] cnt;
    reg        pix_stb;
    always @(posedge CLK) begin
        {pix_stb, cnt} <= cnt + 16'h4000;  // divide-by-4
    end

    //========================================================
    // VGA 640x480 timing generator
    //========================================================
    wire [9:0] x;  // current pixel x position: 0-639
    wire [8:0] y;  // current pixel y position: 0-479

    vga640x480 display (
        .i_clk     (CLK),
        .i_pix_stb (pix_stb),
        .i_rst     (rst),
        .o_hs      (VGA_HS_O), 
        .o_vs      (VGA_VS_O), 
        .o_x       (x), 
        .o_y       (y)
    );

    //========================================================
    // Horizontal line regions (14 strips)
    //========================================================
    localparam integer LEFT   = 0;
    localparam integer RIGHT  = 640;  // <-- was 680, should be 640 for 640x480
    localparam integer TOP    = 0;
    localparam integer BOTTOM = 480;

    localparam integer NUM_LINES  = 30;
    localparam integer LINE_THICK = 16;   // thickness of each line, in pixels

    localparam integer TOTAL_HEIGHT = BOTTOM - TOP;  // 476
    localparam integer STEP         = TOTAL_HEIGHT / NUM_LINES;

    // one-hot line wires: line[0]..line[13]
    wire [NUM_LINES-1:0] line;

    genvar i;
    generate
        for (i = 0; i < NUM_LINES; i = i + 1) begin : gen_lines
            assign line[i] =
                (x >= LEFT)  & (x < RIGHT) &                            // full width of box
                (y >= TOP + i*STEP) & (y < TOP + i*STEP + LINE_THICK);  // strip of height LINE_THICK
        end
    endgenerate

    //========================================================
    // Base color selection via line_color_controller
    //========================================================
    wire [3:0] R_val;
    wire [3:0] G_val;
    wire [3:0] B_val;
    
    

    line_color_controller #(
        .NUM_LINES(NUM_LINES)
    ) color_inst (
        .line       (line),
        .random_num (8'd0),
        .hit        (hit),
        .R          (R_val),
        .G          (G_val),
        .B          (B_val),
        .x          (x),
        .y          (y)
    );

    //========================================================
    // Overlay: decoration (moving block[s])
    //========================================================
    wire       ov_on;
    wire [3:0] R_ov, G_ov, B_ov;

    decoration overlay_inst (
        .CLK        (CLK),
        .x          (x),
        .y          (y),
        .random_num (8'd0),
        .hit        (hit),
        .overlay_on (ov_on),
        .R          (R_ov),
        .G          (G_ov),
        .B          (B_ov),
        .car_x_pos(car_x_pos), .log_x_pos(log_x_pos), .car_y_pos(car_y_pos), .log_y_pos(log_y_pos), .log_thickness(log_thickness), .car_thickness(car_thickness)
    );
    
     wire [3:0] R_txt, G_txt, B_txt;

    textBar tb (
        .x          (x),
        .y          (y),
        .R          (R_txt),
        .G          (G_txt),
        .B          (B_txt),
        .bcd_score(bcd_score),
        .enable_lives(lives),
        .isOccupied(lp_isOccupied),
        .bcdtimer(bcdtimer)
    );
    
    wire [3:0] frogR, frogG, frogB;
    
    frogLayer fl (.x(x), .y(y), .frogX(frog_pos_x), .frogY(frog_pos_y), .R(frogR), .G(frogG), .B(frogB),.orientation(frog_orientation));
    
    wire [3:0] textR, textG, textB;
    textOverlay to(.x(x), .y(y), .R(textR), .G(textG), .B(textB), .enable(enable), .msgNum(instructions), .clk(CLK));

    //========================================================
    // Final VGA output: overlay wins where ov_on = 1
    //========================================================
    
    wire text_on = (R_txt != 0) || (G_txt != 0) || (B_txt != 0);
    wire frog_on = (frogR != 0) || (frogG != 0) || (frogB != 0);
    wire overlay_on = (textR != 0) || (textG != 0) || (textB != 0);

// Registered (debounced) VGA outputs
reg [3:0] VGA_R_reg, VGA_G_reg, VGA_B_reg;

always @(posedge CLK) begin
    if (pix_stb) begin
        // Priority: text > frog > decoration > text > background
        if (overlay_on) begin
            VGA_R_reg <= textR;
            VGA_G_reg <= textG;
            VGA_B_reg <= textB;
        
        end else if (frog_on) begin
            VGA_R_reg <= frogR;
            VGA_G_reg <= frogG;
            VGA_B_reg <= frogB;
        end else if (ov_on) begin
            VGA_R_reg <= R_ov;
            VGA_G_reg <= G_ov;
            VGA_B_reg <= B_ov;
        end else if (text_on) begin
            VGA_R_reg <= R_txt;
            VGA_G_reg <= G_txt;
            VGA_B_reg <= B_txt;
        end else begin
            VGA_R_reg <= R_val;
            VGA_G_reg <= G_val;
            VGA_B_reg <= B_val;
        end
        // =======================================================
        // 1-pixel black border override (left + right edges)
        // =======================================================
        if (y >= 10'd0 && y <= 10'd1) begin
            VGA_R_reg <= 4'h4;
            VGA_G_reg <= 4'hF;
            VGA_B_reg <= 4'h0;
        end
        if (x == 10'd0 || x == 10'd639) begin
            VGA_R_reg <= 4'h0;
            VGA_G_reg <= 4'h0;
            VGA_B_reg <= 4'h0;
        end
    end
end

assign VGA_R = VGA_R_reg;
assign VGA_G = VGA_G_reg;
assign VGA_B = VGA_B_reg;

    

endmodule
