`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/04/2025 11:28:25 PM
// Design Name: 
// Module Name: process1
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module process1(clk,reset,movement,processedsignal);
	input clk;
	input reset;
	input [3:0]movement;
 	output [3:0] processedsignal;
 	wire [3:0] w1;
	debouncer upmovement(.clk(clk), .reset(reset), .insignal(movement[0]), .outsignal(w1[0]));
	checkfornegedge upm(.clk(clk), .reset(reset), .signalin(w1[0]), .signalout(processedsignal[0]));
	
	debouncer rightmovement(.clk(clk), .reset(reset), .insignal(movement[1]), .outsignal(w1[1]));
	checkfornegedge rightmove(.clk(clk), .reset(reset), .signalin(w1[1]), .signalout(processedsignal[1]));
	
	debouncer leftmovement(.clk(clk), .reset(reset), .insignal(movement[2]), .outsignal(w1[2]));
	checkfornegedge leftmove(.clk(clk), .reset(reset), .signalin(w1[2]), .signalout(processedsignal[2]));
	
	debouncer downmovement(.clk(clk), .reset(reset), .insignal(movement[3]), .outsignal(w1[3]));
	checkfornegedge downmove(.clk(clk), .reset(reset), .signalin(w1[3]), .signalout(processedsignal[3]));
endmodule
