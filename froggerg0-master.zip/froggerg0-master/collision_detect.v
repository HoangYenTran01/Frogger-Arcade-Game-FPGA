module collision_detect (
    clk,
    reset,
    log_pos,
    car_pos,
    log_size,
    car_size,
    frog_pos,
    collision_type,
    log_detect,
    prev_frogs
);
  parameter LOG_NUMBER = 17;
  parameter CAR_NUMBER = 14;
  parameter [1:0] DEATH = 2'b01, HOME = 2'b10;  // collision types
  parameter SCREEN_WIDTH = 640;
  parameter SCREEN_HEIGHT = 480;
  parameter X_BITS = $clog2(SCREEN_WIDTH);
  parameter Y_BITS = $clog2(SCREEN_HEIGHT);
  parameter OBJ_HEIGHT = 32; // all objects have same fixed height
  parameter MAX_OBJ_WIDTH_BITS = 10;
  parameter MAX_OBJ_HEIGHT_BITS = $clog2(OBJ_HEIGHT);
  parameter HOME_NUMBER = 5;


  input clk, reset;
  // positions in {..., ypos1, y-pos0, ..., xpos1, xpos0}
  input [LOG_NUMBER*(Y_BITS+X_BITS)-1:0] log_pos;
  input [CAR_NUMBER*(Y_BITS+X_BITS)-1:0] car_pos;
  // sizes in {..., obj1height, obj0height, ..., obj1width, obj0width}
  input [LOG_NUMBER*(MAX_OBJ_WIDTH_BITS+MAX_OBJ_HEIGHT_BITS)-1:0] log_size;
  input [CAR_NUMBER*(MAX_OBJ_WIDTH_BITS+MAX_OBJ_HEIGHT_BITS)-1:0] car_size;
  // frog position in {frogpos_y, frogpos_x}
  input [X_BITS+Y_BITS-1:0] frog_pos;
  output [1:0] collision_type;  // type of collsion to movement module
  output log_detect;  // 1 if encuonter log
  output reg [HOME_NUMBER-1 :0] prev_frogs;
  
  wire [1:0] current_zone;
  wire [Y_BITS-1:0] frog_posy;
  assign frog_posy = frog_pos[X_BITS+Y_BITS-1:X_BITS];
  // determine the zone the frog is currently in
  zone_detect #(
      .SCREEN_HEIGHT(SCREEN_HEIGHT),
      .OBJ_HEIGHT(OBJ_HEIGHT)
  ) zone (
      .frog_pos(frog_posy),  // y coord of frog position
      .zone(current_zone)  // current zone
  );

  // generate reset signal to disable all irrelevant region modules
  reg [2:0] regional_reset;  // {grass, water, road}
  always @(*) begin
    case (current_zone)
      2'b01:   regional_reset <= 3'b001;
      2'b10:   regional_reset <= 3'b010;
      2'b11:   regional_reset <= 3'b100;
      default: regional_reset <= 3'b000;
    endcase
  end

  // determine whether frog dies
  wire [3:0] death;
  road_death #(
      .CAR_NUMBER(CAR_NUMBER),
      .SCREEN_HEIGHT(SCREEN_HEIGHT),
      .SCREEN_WIDTH(SCREEN_WIDTH),
      .MAX_OBJ_WIDTH_BITS(MAX_OBJ_WIDTH_BITS),
      .MAX_OBJ_HEIGHT_BITS(MAX_OBJ_HEIGHT_BITS)
  ) road (
      .clk(clk),
      .reset(regional_reset[0]),
      .car_pos(car_pos),
      .car_size(car_size),
      .frog_pos(frog_pos),
      .death(death[0])
  );

  water_death #(
      .LOG_NUMBER(LOG_NUMBER),
      .SCREEN_HEIGHT(SCREEN_HEIGHT),
      .SCREEN_WIDTH(SCREEN_WIDTH),
      .MAX_OBJ_HEIGHT_BITS(MAX_OBJ_HEIGHT_BITS),
      .MAX_OBJ_WIDTH_BITS(MAX_OBJ_WIDTH_BITS)
  ) water (
      .clk(clk),
      .reset(regional_reset[1]),
      .log_pos(log_pos),
      .log_size(log_size),
      .frog_pos(frog_pos),
      .death(death[1])
  );
  
  assign log_detect = ~death[1] && (current_zone == 2'b10);

  // check if frog reaches home
  wire home;
  wire [X_BITS-1:0] frog_pos_x;
  wire [HOME_NUMBER -1:0] home_touch;
  reg [HOME_NUMBER-1:0] new_frog;
  wire [HOME_NUMBER-1:0] prev_frogs_i;
  
  assign frog_pos_x = frog_pos[9:0];
  home_detect #(
      .SCREEN_WIDTH(SCREEN_WIDTH),
      .HOME_NUMBER(HOME_NUMBER)
  ) home1 (
      .clk(clk),
      .reset(regional_reset[2]),
      .frog_posx(frog_pos_x),
      .prev_frogs(prev_frogs),
      .home({death[2], home}),
      .home_touch(home_touch),
      .frog_posy(frog_posy)
  );
  
  always @(posedge clk) begin
    if (regional_reset[2] == 0) new_frog <= 0;
    else new_frog<=home_touch;
  end

  // look for previous frog positions
  prev_frog #(
      .SCREEN_WIDTH(SCREEN_WIDTH),
      .HOME_NUMBER(HOME_NUMBER)
  ) prev (
      .clk(clk),
      .reset(reset),  // should not reset unless game restarts
      .new_frog(new_frog),
      .prev_frog(prev_frogs_i)
  );
  always @ (posedge clk) begin
    if (reset == 0) prev_frogs <= 0;
    else prev_frogs <= prev_frogs_i;
  end

  // generate collision type signal for movement module
  type_detect collision (
      .clk(clk),
      .reset(reset),
      .zone(current_zone),
      .road_die(death[0]),
      .water_die(death[1]),
      .grass_die({death[2], home}),
      .collision_type(collision_type)
  );

endmodule
