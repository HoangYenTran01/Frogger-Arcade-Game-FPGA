`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/06/2025 02:44:35 AM
// Design Name: 
// Module Name: timetext
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module timetext(
    input [5:0] x,
    input [4:0] y,
    output [3:0] R,
    output [3:0] G,
    output [3:0] B
    );
    
    
    reg[11:0] timetxt [0:1023];
    initial $readmemh("time.mem", timetxt);
    
    wire [9:0] pos;
    assign pos = x + y * 64;
    
    assign R = timetxt[pos][11:8];
    assign G = timetxt[pos][7:4];
    assign B = timetxt[pos][3:0];
    
    
endmodule
