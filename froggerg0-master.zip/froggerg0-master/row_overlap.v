`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/06/2025 02:19:15 AM
// Design Name: 
// Module Name: row_overlap
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module row_overlap(row_x,row_y, spacing, overlap

    );
      parameter LOG_NUMBER = 5;
  parameter CAR_NUMBER = 3;
  parameter [1:0] DEATH = 2'b01, HOME = 2'b10;  // collision types
  parameter SCREEN_WIDTH = 640;
  parameter SCREEN_HEIGHT = 480;
  parameter [2:0] VOID = 3'b000, FROG = 3'b001, CAR = 3'b010, LOG = 3'b011;  // object type
  parameter X_BITS = $clog2(SCREEN_WIDTH);
  parameter Y_BITS = $clog2(SCREEN_HEIGHT);
  parameter OBJ_HEIGHT = 32; // all objects have same fixed height
  parameter MAX_OBJ_WIDTH_BITS = 10;
  parameter MAX_OBJ_HEIGHT_BITS = $clog2(OBJ_HEIGHT);
  parameter HOME_NUMBER = 5;
  
  input [X_BITS-1:0] row_x;
  input [Y_BITS -1:0] row_y;
  input [X_BITS-1:0] spacing;
  output overlap;
  
  
  
  
    
endmodule
