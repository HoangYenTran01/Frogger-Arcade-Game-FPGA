`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/06/2025 11:40:43 PM
// Design Name: 
// Module Name: frogspeedwithlog
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module frogspeedwithlog(clk,frog_y_current,logspeed);
    parameter STEP = 1;
    parameter SCREEN_HEIGHT = 480;
    parameter Y_BITS = $clog2(SCREEN_HEIGHT);
    
    input clk;
    input [Y_BITS-1:0] frog_y_current;
    output reg signed [4:0] logspeed;
    reg [$clog2(5000000)-1:0]speed;
    always @(posedge clk) begin
        speed <= speed + 1;
        if (speed == 31'd5000000) begin
            speed <= 0;
            if (frog_y_current == 9'd63) begin
                logspeed <= 3*STEP;
            end
            else if (frog_y_current == 9'd95) begin
                logspeed <= -3*STEP;
            end
            else if (frog_y_current == 9'd127) begin
                logspeed <= -4*STEP; // Positive goes to the lefet, same as right? too much What about 0?  
            end
            else if (frog_y_current == 9'd159) begin
                logspeed <= 2*STEP;
            end
            else if (frog_y_current == 9'd191) begin
                logspeed <= -3*STEP;
            end
            else begin
                logspeed <= 0;
            end
        end
        else begin
            logspeed <= 0;
        end
    end
endmodule
