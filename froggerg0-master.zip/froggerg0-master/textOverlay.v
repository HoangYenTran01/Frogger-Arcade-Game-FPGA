`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/06/2025 09:59:27 PM
// Design Name: 
// Module Name: textOverlay
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module textOverlay (


    output reg  [3:0]           R,
    output reg  [3:0]           G,
    output reg  [3:0]           B,
    input wire [2:0] msgNum,
    input wire enable,
    input wire [9:0] x,  // current pixel x position: 0-639
    input wire [8:0] y,  // current pixel y position: 0-479
    input clk
);
    
    (* rom_style="block", keep="true", dont_touch="true" *) reg [7:0] msgData [0:307199];
    initial begin  $readmemb("messages.mem", msgData) ; end
    
    
    
    
    wire [18:0] num;
    reg [7:0] pixelBit;
    assign num = x + y * 640;
    
    always @(posedge clk) begin
        pixelBit <= msgData[num];
    end
    
    always @(*) begin

        if (enable) begin
        
            if (pixelBit[msgNum] == 1'b0) begin
                R = 4'hF; G = 4'h0; B = 4'h2;
            end else
                R = 0; G = 0; B = 0;
        
        end else {R,G,B} = 12'h000;
    end
endmodule
