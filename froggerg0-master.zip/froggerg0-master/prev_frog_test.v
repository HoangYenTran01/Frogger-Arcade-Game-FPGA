`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/04/2025 11:58:28 PM
// Design Name: 
// Module Name: prev_frog_test
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module prev_frog_test(

    );
    
    reg clk, reset;
    reg [2:0] new_frog_pos;
    wire [4:0] prev_frog;
    
    prev_frog # (.X_BITS(3)) dut (.clk(clk), .reset(reset), .new_frog_pos(new_frog_pos), .prev_frog(prev_frog));
    
    initial begin
  clk <= 1'b0;
  reset <= 1'b0;
  new_frog_pos <= 3'b001;
  #15 reset <= 1'b1;
  #40 new_frog_pos <= 3'b010;
  
  end
  
    always begin
    #10 clk <= ~clk;
  end
    
endmodule
