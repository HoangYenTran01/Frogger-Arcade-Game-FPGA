module display_control (
    clk,
    reset,
    bin_in,
    digit_select,
    bin_out
);
  input clk, reset;
  input [31:0] bin_in;
  output reg [7:0] digit_select;  // digit_select has exactly one 0
  output reg [3:0] bin_out;
  reg [2:0] internal_counter;

  always @(posedge clk or negedge reset) begin
    if (reset == 1'b0) begin
      internal_counter <= 3'b0;
    end else begin
      internal_counter <= internal_counter + 1;  // loops between 00, 01, 10, 11
    end

  end

  always @(*) begin
    case (internal_counter)
      3'b000: begin
        digit_select = 8'b11111110;  // right most digit on display
        bin_out = bin_in[3:0];
      end
      3'b001: begin
        digit_select = 8'b11111101;
        bin_out = bin_in[7:4];
      end
      3'b010: begin
        digit_select = 8'b11111011;
        bin_out = bin_in[11:8];
      end
      3'b011: begin
        digit_select = 8'b11110111;
        bin_out = bin_in[15:12];
      end
      3'b100: begin
        digit_select = 8'b11101111;
        bin_out = bin_in[19:16];
      end
      3'b101: begin
        digit_select = 8'b11011111;
        bin_out = bin_in[23:20];
      end
      3'b110: begin
        digit_select = 8'b10111111;
        bin_out = bin_in[27:24];
      end
      3'b111: begin
        digit_select = 8'b01111111;
        bin_out = bin_in[31:28];
      end
    endcase
  end

endmodule
