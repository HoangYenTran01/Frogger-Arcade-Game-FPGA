// assuming frog is already in grass region
// check if the frog dies or reached home


module home_detect (
    clk,
    reset,
    frog_posx,  
    frog_posy,
    home,
    prev_frogs,  // if previous frogs are on position, then frog dies
    home_touch
);
  parameter [1:0] NOTHING = 2'b00, DEATH = 2'b10, HOME = 2'b01;
  parameter SCREEN_WIDTH = 640;
  parameter X_BITS = $clog2(SCREEN_WIDTH);
  parameter SCREEN_HEIGHT = 480;
  parameter Y_BITS = $clog2(SCREEN_HEIGHT);
  
  parameter MARGIN_SIZE = 32;  // margin width on the side of the screen
  parameter HOME_NUMBER = 5;
  parameter HOME_WIDTH = 64;


  input clk, reset;
  input [X_BITS-1:0] frog_posx;
  input [Y_BITS-1:0] frog_posy;
  input [HOME_NUMBER-1:0] prev_frogs;
  output reg [1:0] home;
  
  output reg [HOME_NUMBER-1:0] home_touch;
  wire [HOME_NUMBER-1:0] home_touch_int;
  
  genvar home_index;
  generate
  for (home_index=0; home_index < HOME_NUMBER; home_index = home_index + 1) begin
  wire overlap;
  check_overlap home_check (
  .frog_pos_x(frog_posx),
          .obj_pos_x(MARGIN_SIZE + home_index*2*HOME_WIDTH),
          .obj_size_x(
              HOME_WIDTH
          ),.frog_pos_y(frog_posy),
          .obj_pos_y(32),
          .obj_size_y(0), .overlap(home_touch_int[home_index] ));
   end
   endgenerate
//always @(*) begin
//if ((frog_posx <= 600) && (frog_posx >= 552)) begin
//            home_touch_int[4] <= 1;
//            end
//            else if ((frog_posx <= 472) && (frog_posx >= 424)) begin
//            home_touch_int[3] <= 1;
//            end
//            else if ((frog_posx <= 244) && (frog_posx >= 296)) begin
//            home_touch_int[2] <= 1;
//            end
//            else if ((frog_posx <= 216) && (frog_posx >= 168)) begin
//            home_touch_int[1] <= 1;
//            end
//            else if ((frog_posx <= 88) && (frog_posx >= 40)) begin
//            home_touch_int[0] <= 1;
//            end
// end
          
//  check_overlap home_check1 (
//  .frog_pos_x(frog_posx),
//          .obj_pos_x(0),
//          .obj_size_x(
//             320
//          ),.frog_pos_y(frog_posy),
//          .obj_pos_y(32),
//          .obj_size_y(0), .overlap(home_touch_int[0] ));
          
//  check_overlap home_check2 (
//  .frog_pos_x(frog_posx),
//          .obj_pos_x(352),
//          .obj_size_x(
//              320
//          ),.frog_pos_y(frog_posy),
//          .obj_pos_y(32),
//          .obj_size_y(0), .overlap(home_touch_int[1] ));
  
//   check_overlap home_check3 (
//  .frog_pos_x(frog_posx),
//          .obj_pos_x(296),
//          .obj_size_x(
//              128
//          ),.frog_pos_y(frog_posy),
//          .obj_pos_y(32),
//          .obj_size_y(0), .overlap(home_touch_int[2] ));
   
//    check_overlap home_check4 (
//  .frog_pos_x(frog_posx),
//          .obj_pos_x(424),
//          .obj_size_x(
//              128
//          ),.frog_pos_y(frog_posy),
//          .obj_pos_y(32),
//          .obj_size_y(0), .overlap(home_touch_int[3] ));
          
    
//     check_overlap home_check5 (
//  .frog_pos_x(frog_posx),
//          .obj_pos_x(552),
//          .obj_size_x(
//              128
//          ),.frog_pos_y(frog_posy),
//          .obj_pos_y(32),
//          .obj_size_y(0), .overlap(home_touch_int[4] ));

  // assume that the first position is dead zone, second is home zone, ...
  always @(posedge clk) begin
    if (reset == 1'b0) begin
      home <= NOTHING;
      home_touch <= 0;
    end else begin
      if (home_touch_int == 0 ) home <= DEATH;
      else if ((prev_frogs&home_touch_int) !=0) home <= DEATH;
      else begin home <= HOME; home_touch <= home_touch_int; end
    end
  end
endmodule
