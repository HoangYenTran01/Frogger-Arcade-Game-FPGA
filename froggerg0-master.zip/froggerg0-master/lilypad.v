`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 09:58:43 PM
// Design Name: 
// Module Name: lilypad
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 03:55:50 PM
// Design Name: 
// Module Name: forg32
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module lilypad(
    input [5:0] x,
    input [5:0] y,
    input isOccupied,
    output reg [3:0] R,
    output reg [3:0] G,
    output reg [3:0] B
    );
    
    
    reg[11:0] noFrog [0:4096];
    reg[11:0] frog [0:4096];
    initial $readmemh("lilypad64.mem", noFrog);
    initial $readmemh("frogPad64.mem", frog);
    
    wire [11:0] pos;
    assign pos = x + y * 64;
    
    always @(*) begin
        if(!isOccupied) begin
            R = noFrog[pos][11:8];
            G = noFrog[pos][7:4];
            B = noFrog[pos][3:0];
        
        end else begin
            R = frog[pos][11:8];
            G = frog[pos][7:4];
            B = frog[pos][3:0];
            
            end
        
    end
    
    
endmodule
