`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 03:07:04 PM
// Design Name: 
// Module Name: belowrivermerge
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module belowrivermerge(start_game,clk,reset,movement,bcd_score, lives,log_pos,car_pos,log_size,car_size, frog_x_current, frog_y_current, collision,checksignal, prev_frogs, lives, frog_orientation);
    parameter LOG_NUMBER = 17;
    parameter CAR_NUMBER = 14;
    parameter SCREEN_WIDTH = 640;
    parameter SCREEN_HEIGHT = 480;
    parameter X_BITS = $clog2(SCREEN_WIDTH);
    parameter Y_BITS = $clog2(SCREEN_HEIGHT);
    parameter OBJECT_HEIGHT = 32;
    parameter MAX_OBJ_WIDTH_BITS = 10;
    parameter MAX_OBJ_HEIGHT_BITS = $clog2(OBJECT_HEIGHT);
    parameter UI_MARGIN = 32;
    parameter STEP = 1;

    parameter y_origin = SCREEN_HEIGHT-OBJECT_HEIGHT-1-UI_MARGIN;
    parameter x_origin = SCREEN_WIDTH/2 -1 -32;
    parameter lives_num = 3'd6;

    input clk, reset;
    input start_game;
    input [3:0] movement;
    wire [1:0] collisiontype;
    output [15:0] bcd_score;
    output [2:0] lives;  // onehot encoding COMMENTED
    output [X_BITS-1:0] frog_x_current;
    output [Y_BITS-1:0] frog_y_current;
    output [4:0] prev_frogs;
    
    // wire [(Y_BITS + X_BITS)-1: 0] frog_pos = {frog_y_current, frog_x_current}; //take the ceiling log to find number of bits to present //$clog2(y_min)-1)
//    wire [11: 0] frog_pos = {frog_y_current, frog_x_current};
    // positions in {..., ypos1, y-pos0, ..., xpos1, xpos0}
    input [LOG_NUMBER*(Y_BITS+X_BITS)-1:0] log_pos;
    input [CAR_NUMBER*(Y_BITS+X_BITS)-1:0] car_pos;
    input [LOG_NUMBER*(MAX_OBJ_WIDTH_BITS)-1:0] log_size;
    input [CAR_NUMBER*(MAX_OBJ_WIDTH_BITS)-1:0] car_size;
    output [1:0] collision;
    output [3:0] frog_orientation;
    output checksignal;

    
    wire on_log;
    wire [11:0] score;
    wire [2:0] life_int; 
    wire signed [2:0 ]logspeed;
//    parameter x_min = 0, x_max = 20, y_min = 15, y_max = 0; // HIGHEST POINT HAS Y of 0
//    parameter frog_to_go_home = 5;s
//    parameter STEP_Y = 1, STEP_X = 1; //scaled based on pixels
//    //Original position
//    parameter y_origin = 6'd15, x_origin = 6'd10;
//    parameter X_BITS = $clog2(x_max);
//    parameter Y_BITS = $clog2(y_min);

    movementandscore #(
        .X_BITS(X_BITS), .Y_BITS(Y_BITS), .y_origin(y_origin), .x_origin(x_origin)
    )
    moveandscore(.start_game(start_game),.clk(clk),.reset(reset),.collisiontype(collisiontype),.movement(movement), .score(score), .lives(life_int), .frog_y_current(frog_y_current),
     .frog_x_current(frog_x_current),.checksignal(checksignal), .on_log(on_log),.logspeed(logspeed), .frog_orientation(frog_orientation));
    
    to_bcd_score bcd (.bin({2'b00, score}), .bcd(bcd_score));
    lives_decoder dec (.bin(life_int), .screen(lives)); 
    
    frogspeedwithlog #(
    .STEP(STEP),
    .SCREEN_HEIGHT(SCREEN_HEIGHT),
    .Y_BITS(Y_BITS)
    )
    calculated_frog_speed(
    .clk(clk),.frog_y_current(frog_y_current), .logspeed(logspeed)
    );
    
    collision_detect #(
    .X_BITS(X_BITS),
    .Y_BITS(Y_BITS),
   .LOG_NUMBER(LOG_NUMBER),
   .CAR_NUMBER(CAR_NUMBER),
   .SCREEN_WIDTH(SCREEN_WIDTH), 
   .SCREEN_HEIGHT(SCREEN_HEIGHT),
   .MAX_OBJ_WIDTH_BITS(MAX_OBJ_WIDTH_BITS),
   .MAX_OBJ_HEIGHT_BITS(MAX_OBJ_HEIGHT_BITS)
   )
    collisiondetect(.clk(clk),.reset(reset), .log_pos(log_pos),.car_pos(car_pos),
    .log_size({{LOG_NUMBER{OBJECT_HEIGHT}}, log_size}),
    .car_size({{CAR_NUMBER{OBJECT_HEIGHT}}, car_size}),
    .frog_pos({frog_y_current, frog_x_current}),
    .collision_type(collisiontype), 
    .log_detect(on_log), .prev_frogs(prev_frogs));

assign collision = collisiontype;
endmodule
