from PIL import Image


print("enter filename pls: ", end="")
name = input()

img = Image.open(name + ".bmp").convert("RGB")
width, height = img.size


with open(name + ".mem", "w") as f:
    for y in range(height):
        for x in range(width):
            r, g, b = img.getpixel((x, y))
            r4 = r >> 4
            g4 = g >> 4
            b4 = b >> 4
            f.write(f"{r4:X}{g4:X}{b4:X}\n")

