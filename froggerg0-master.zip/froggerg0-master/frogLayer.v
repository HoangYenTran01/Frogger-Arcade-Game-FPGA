`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 03:39:56 PM
// Design Name: 
// Module Name: frogLayer
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module frogLayer(
    input [9:0] x,
    input [8:0] y,
    input [9:0] frogX,
    input [8:0] frogY,
    input [3:0] orientation,
    output reg [3:0] R,
    output reg [3:0] G,
    output reg [3:0] B
    );
    
    wire [4:0] tex_y, tex_x;
    
    assign tex_y = (y >= frogY) ? (y - frogY) : 6'd0;
    assign tex_x = (x >= frogX) ? (x - frogX) : 6'd0;
    
    wire [3:0] frogR, frogG, frogB;
    
    forg32 f32 (.x(tex_x), .y(tex_y), .R(frogR), .G(frogG), .B(frogB), .orientation(orientation));
    
    always @(*) begin
        
        if (x >= frogX && x < frogX + 32 && y >= frogY && y < frogY + 32) begin
            R = frogR; G = frogG; B = frogB;  
        end else begin
            R = 4'b0000; G = 4'b0000; B = 4'b0000;
        end
        
    end
    
endmodule
