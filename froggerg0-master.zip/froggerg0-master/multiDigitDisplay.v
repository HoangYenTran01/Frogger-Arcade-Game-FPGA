module multiDigitDisplay(
    input [5:0] x,
    input [3:0] y,
    input [15:0] bcdDigit,
    output reg [3:0] R,
    output reg [3:0] G,
    output reg [3:0] B
    );
    
    wire[3:0] tex_x = x % 16;
    
    wire [3:0] dd1R, dd1G, dd1B;
    wire [3:0] dd2R, dd2G, dd2B;
    wire [3:0] dd3R, dd3G, dd3B;
    wire [3:0] dd4R, dd4G, dd4B;
    
    digitDisplay dd1(
    .x(tex_x),
    .y(y),
    .bcdDigit(bcdDigit[15:12]),
    .R(dd1R),
    .G(dd1G),
    .B(dd1B)
    );
    
    digitDisplay dd2(
    .x(tex_x),
    .y(y),
    .bcdDigit(bcdDigit[11:8]),
    .R(dd2R),
    .G(dd2G),
    .B(dd2B)
    
    );digitDisplay dd3(
    .x(tex_x),
    .y(y),
    .bcdDigit(bcdDigit[7:4]),
    .R(dd3R),
    .G(dd3G),
    .B(dd3B)
    
    );digitDisplay dd4(
    .x(tex_x),
    .y(y),
    .bcdDigit(bcdDigit[3:0]),
    .R(dd4R),
    .G(dd4G),
    .B(dd4B)
    );
    
    wire [1:0] val2Print;
    assign val2Print = x >> 4;
    
    always @(*) begin
        case (val2Print)
            2'b00:begin R = dd1R; G = dd1G; B = dd1B; end
            2'b01:begin R = dd2R; G = dd2G; B = dd2B; end
            2'b10:begin R = dd3R; G = dd3G; B = dd3B; end
            2'b11:begin R = dd4R; G = dd4G; B = dd4B; end
        endcase
    end
    
    
    
    
    
    endmodule