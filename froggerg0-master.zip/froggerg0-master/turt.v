`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/03/2025 10:59:08 PM
// Design Name: 
// Module Name: turt
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module turt(
    input [4:0] x,
    input [4:0] y,
    input oneHundredMHz,
    output reg [3:0] R,
    output reg [3:0] G,
    output reg [3:0] B
);

    // Counters
    reg [7:0] yCtr = 0;
    reg whichTurt = 0;
    reg [25:0] counter = 0;

    // Clocked toggle every 0.5s
    always @(posedge oneHundredMHz) begin
        if (counter < 50000000) begin
            counter <= counter + 1;
        end else begin
            counter <= 0;
            whichTurt <= ~whichTurt;
        end
    end

    // Sprite memory
    reg [11:0] turt1 [0:1023];
    initial $readmemh("turt.mem", turt1);

    reg [11:0] turt2 [0:1023];
    initial $readmemh("turt2.mem", turt2);

    wire [9:0] pos = x + y * 32;

    // RGB output
    always @(*) begin
        if (whichTurt)
            {R,G,B} = turt1[pos];
        else
            {R,G,B} = turt2[pos];
    end

endmodule