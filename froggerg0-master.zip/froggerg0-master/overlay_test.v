`timescale 1ns / 1ps
// testbench for check overlap module
module overlay_test ();
  reg [2:0] frog_pos_x, frog_pos_y, obj_pos_x, obj_pos_y;
  reg [1:0] obj_size_y, obj_size_x;
  wire overlap;


  check_overlap #(
      .X_BITS(3),
      .Y_BITS(3),
      .MAX_OBJ_WIDTH_BITS(2),
      .MAX_OBJ_HEIGHT_BITS(2)
  ) dut (
      .frog_pos_x(frog_pos_x),
      .frog_pos_y(frog_pos_y),
      .obj_pos_x(obj_pos_x),
      .obj_pos_y(obj_pos_y),
      .obj_size_x(obj_size_x),
      .obj_size_y(obj_size_y),
      .overlap(overlap)
  );
  initial begin
    obj_size_y <= 1;
    obj_size_x <= 2;
    obj_pos_x  <= 3'd4;
    obj_pos_y  <= 3'd2;
    frog_pos_x <= 0;
    frog_pos_y <= 0;
  end

  always begin
    // loop over all frog positions
    #10 frog_pos_x <= frog_pos_x + 1;
    if (frog_pos_x == 3'b111) frog_pos_y <= frog_pos_y + 1;
  end


endmodule
