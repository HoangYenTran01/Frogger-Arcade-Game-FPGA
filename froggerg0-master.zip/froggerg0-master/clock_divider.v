module clock_divider #(parameter FREQ = 1000)(clk, reset, divided_clk);
    input clk, reset;
    output reg divided_clk;
    
    localparam MAX = 100000000/FREQ/2;  // the internal clock is 100MHz. want to find 1/2 period
    
    reg [26:0] counter;  
    
    always @(posedge clk or negedge reset)begin
        if (reset == 1'b0) begin  // active low reset
            divided_clk <= 1'b0;
            counter <= 27'b0;  // lowest clock frequency is 1Hz -> largest counter is 27 bits
        end else begin
            counter <= counter +1;
            if (counter == MAX)begin  // flip at 1/2 period
                divided_clk <= ~divided_clk;
                counter <= 27'b0;
            end
        end
    end
endmodule
