`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/01/2025 08:23:23 PM
// Design Name: 
// Module Name: frog
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module frog(
    input [3:0] x,
    input [3:0] y,
    input enable,
    output reg [3:0] R,
    output reg [3:0] G,
    output reg [3:0] B
    );
    
    
    reg[11:0] forg [0:255];
    initial $readmemh("forg.mem", forg);
    
    wire [9:0] pos;
    assign pos = x + y * 16;
    
    always @(*) begin
        
        if (enable) begin
            R = forg[pos][11:8];
            G = forg[pos][7:4];
            B = forg[pos][3:0];
         end else begin
         
            R = 0; G = 0; B = 0;
         
         end
    end
    
    
    
endmodule
