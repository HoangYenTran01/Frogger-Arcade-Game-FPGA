`timescale 1ns / 1ps
// testbench for check overlap module
module zone_test ();


  parameter LOG_NUMBER = 5;
  parameter CAR_NUMBER = 3;
  parameter [1:0] DEATH = 2'b01, HOME = 2'b10;  // collision types
  parameter SCREEN_WIDTH = 20;
  parameter SCREEN_HEIGHT = 15;
  parameter [2:0] VOID = 3'b000, FROG = 3'b001, CAR = 3'b010, LOG = 3'b011;  // object type
  parameter X_BITS = $clog2(SCREEN_WIDTH);
  parameter Y_BITS = $clog2(SCREEN_HEIGHT);
  parameter MAX_OBJ_WIDTH_BITS = 4;
  parameter MAX_OBJ_HEIGHT_BITS = 2;
  parameter WATER_ZONE_START = 7;
  parameter WATER_ZONE_END = 11;
  parameter ROAD_ZONE_START = 2;
  parameter ROAD_ZONE_END = 5;
  
    reg [Y_BITS-1:0] frog_pos_y;
  reg [1:0] obj_size_y, obj_size_x;
  wire [1:0] current_zone;

  zone_detect #(
      .SCREEN_HEIGHT(SCREEN_HEIGHT),
      .WATER_ZONE_START(WATER_ZONE_START),
      .WATER_ZONE_END(WATER_ZONE_END),
      .ROAD_ZONE_START(ROAD_ZONE_START),
      .ROAD_ZONE_END(ROAD_ZONE_END)
  ) dut (
      .frog_pos(frog_pos_y),  // y coord of frog position
      .zone(current_zone)  // current zone
  );
  initial begin

    frog_pos_y <= 0;
  end

  always begin
    // loop over all frog positions
    #10 frog_pos_y <= frog_pos_y + 1;
  end


endmodule
