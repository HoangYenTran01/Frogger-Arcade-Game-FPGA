// detect whether the frog is in the road zone, water zone, grass zone, or safe zone.

module zone_detect (
    frog_pos,  // y position of the frog only
    zone
);

  parameter SCREEN_HEIGHT = 30;
  parameter Y_BITS = $clog2(SCREEN_HEIGHT);
  parameter OBJ_HEIGHT = 32;
  parameter WATER_ZONE_START = OBJ_HEIGHT+16;
  parameter WATER_ZONE_END = 6*OBJ_HEIGHT;
  parameter ROAD_ZONE_START = 7*OBJ_HEIGHT;
  parameter ROAD_ZONE_END = 12*OBJ_HEIGHT;

  localparam [1:0] ROAD = 2'b01, WATER = 2'b10, GRASS = 2'b11, SAFE = 2'b00;

  input [Y_BITS-1:0] frog_pos;
  output [1:0] zone;

  assign zone = (frog_pos < WATER_ZONE_START)?GRASS:
    (frog_pos <= WATER_ZONE_END)? WATER:
    (frog_pos < ROAD_ZONE_START) ? SAFE:
    (frog_pos <= ROAD_ZONE_END) ? ROAD:
    SAFE;
endmodule
