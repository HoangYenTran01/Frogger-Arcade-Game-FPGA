`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 11:26:30 PM
// Design Name: 
// Module Name: show_coord
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module show_coord(clk, reset, x_coord, y_coord, out, digit_sel

    );
    input clk, reset;
    input [9:0] x_coord;
    input [8:0] y_coord;
    output [6:0] out;
    output [7:0] digit_sel;
    
    wire divided;
    wire [3:0] bin_out;
    wire [31:0] bin_in;
    assign bin_in = {6'b0, x_coord, 7'b0, y_coord};
    
    
    clock_divider #(1000) div (.clk(clk), .reset(reset), .divided_clk(divided));
    display_control disp (.clk(divided), .reset(reset), .bin_in(bin_in), .bin_out(bin_out), .digit_select(digit_sel));
    seven_seg_decoder dec (.I(bin_out), .Y(out));
    
endmodule
