`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/04/2025 08:19:34 PM
// Design Name: 
// Module Name: lifeBar
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module lifeBar(
    input [5:0] x,
    input [3:0] y,
    input [2:0] enable,
    output reg [3:0] R,
    output reg [3:0] G,
    output reg [3:0] B
    );
    
    reg [3:0] xMod; reg[1:0] xDiv;
    
    wire [3:0] frogR [0:2], frogG [0:2], frogB [0:2];
    
    frog f1(.x(xMod), .y(y), .R(frogR[0]), .G(frogG[0]), .B(frogB[0]), .enable(enable[0]));
    frog f2(.x(xMod), .y(y), .R(frogR[1]), .G(frogG[1]), .B(frogB[1]), .enable(enable[1]));
    frog f3(.x(xMod), .y(y), .R(frogR[2]), .G(frogG[2]), .B(frogB[2]), .enable(enable[2]));
    
    
    always @(*) begin
        xDiv = (x >> 4);//ugly but I think it is necessary
        xMod = x % 16;
        
        R = frogR[xDiv]; G = frogG[xDiv];  B = frogB[xDiv]; 
        
        end
    
    
endmodule
