`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/01/2025 08:17:59 PM
// Design Name: 
// Module Name: processperclick
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module processperclick(clk,reset,signalprocess,clicked);
    input clk;
    input reset;
    input signalprocess;
//    reg [7:0] count; // = 8'b0;
    output reg clicked; //reg clicked;
//    reg clickedalr;
    
    //Use state machine to confirm the release
    parameter S0 = 1'b0, S1 = 1'b1; //state 0 -> on. State 1 -> off.
    reg state = S0; // must assign initial state
    always @ (posedge clk or negedge reset) begin
        if (reset == 1'b0)
        begin
            state <= S0;
            clicked <= 1'b0;
        end
        else
        begin
            case (state)
                S0: 
                    if (signalprocess == 1'b0)
                    begin
                        state <= S0; // no detection
                        clicked <= 1'b0;
                    end
                    else if (signalprocess == 1'b1) 
                    begin
                        state <= S1; // move to identify it is up
//                        clicked <= clicked;
                    end 
                S1: 
                    if (signalprocess == 1'b1)
                    begin
                        state <= S1;   
//                        clicked <= clicked; 
                    end
                    else if (signalprocess == 1'b0)
                    begin
                        state <= S0;
                        clicked <= 1'b1; //only increment after signal fully count
//                        clicked <= ~clicked;
                    end
            endcase
        end
    end
//    assign clicked = clickedalr;
endmodule
