`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/07/2025 12:53:25 AM
// Design Name: 
// Module Name: countdown
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module countdown(global_reset, clk1hz, count,enable);
//    input [2:0] countnumber;
////    parameter countbits = $clog2(countnumber);
//    input [2:0] instructiontype; //death
//    input clk1hz;
//    input global_reset;
//    output reg [2:0] count;
//    output reg enable; //start game when the output is 0
    
    //always @(posedge clk1hz or negedge global_reset) begin
    parameter countnumber = 4'd7;
    parameter countbits = $clog2(countnumber);
    input clk1hz;
    input global_reset;
    
    output reg [countbits-1:0] count = countnumber;
    output reg enable; //start game when the output is 0
    always @(posedge clk1hz or negedge global_reset) begin
        if (global_reset == 0)begin
            count <= countnumber;
            enable <= 0;
        end
        else begin
            if (count == 1'b0) begin
                enable <= 1'b1; 
            end 
            else begin
                enable <= 1'b0;
                count <= count - 1'b1;
            end
        end
//        else begin
//            enablegame <= 1'b0;
//        end
    end
endmodule


//        if (global_reset == 0)begin
//            count <= countnumber;
//            enable <= 1'b0;
//        end
//        else begin
//            case (instructiontype)
//                3'b110: begin  // INTRO
//                    count <= count;
//                    enable <= 1'b1;
//                end

//                3'b101: begin  // COUNTDOWN
//                    if (count != 0) begin
//                        count <= count - 1;
//                        enable <= 1'b1;
//                    end else begin
//                        enable <= 1'b0;  // start the game
//                    end
//                end

//                3'b111: begin // GAMEOVER
//                    if (count != 0) begin
//                        count <= count - 1;
//                        enable <= 1'b1;
//                    end else begin
//                        enable <= 1'b0;
//                    end
//                end
//                3'b000: begin // GAME
//                        enable <= 1'b0;
//                end
                

//            endcase
//        end               
//    end
//GAMEOVER
//        if (instructiontype == 3'b111) begin 
//            if (count == 1'b0) begin
//                enablegame <= 1'b0; 
//            end 
//            else begin
//                enablegame <= 1'b1;
//                count <= count - 1'b1;        
//            end
//        end
//        //INTRO 
//        if (instructiontype == 3'b110) begin  
////            count <= countnumber; //already pass in 
//            if (count == 1'b0) begin
//                enablegame <= 1'b0; 
//            end 
//            else begin
//                enablegame <= 1'b1;
//                count <= count - 1'b1;        
//            end
//        //COUNTDOWN 
//        if (diesignal == 1'b0) begin 
//            count <= countnumber;
//        end
//        else begin
//            if (count == 1'b0) begin
//                enablegame <= 1'b0; 
//            end 
//            else begin
//                enablegame <= 1'b1;
//                count <= count - 1'b1;        
//            end
//        end
