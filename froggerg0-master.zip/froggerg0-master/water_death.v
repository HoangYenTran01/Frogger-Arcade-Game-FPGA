// detect whether the frog dies in the water region
// assuming that we already know frog is in water from upstream modules

module water_death (
    clk,
    reset,
    frog_pos,
    log_pos,
    log_size,
    death
);
  parameter LOG_NUMBER = 5;
  parameter SCREEN_WIDTH = 40;
  parameter SCREEN_HEIGHT = 30;
  parameter X_BITS = $clog2(SCREEN_WIDTH);
  parameter Y_BITS = $clog2(SCREEN_HEIGHT);
  parameter MAX_OBJ_WIDTH_BITS = 4;
  parameter MAX_OBJ_HEIGHT_BITS = 2;

  input clk, reset;
  // positions in {..., ypos1, y-pos0, ..., xpos1, xpos0}
  input [LOG_NUMBER*(Y_BITS+X_BITS)-1:0] log_pos;
  // sizes in {..., obj1height, obj0height, ..., obj1width, obj0width}
  input [LOG_NUMBER*(MAX_OBJ_WIDTH_BITS+MAX_OBJ_HEIGHT_BITS)-1:0] log_size;
  // frog position in {frogpos_y, frogpos_x}
  input [X_BITS+Y_BITS-1:0] frog_pos;

  output reg  death;  // death signal is active high
  
  wire death_int;


  wire [LOG_NUMBER-1:0] hit;  // whether frog hits log number i where i is the index

  genvar log_index;
  generate
    for (log_index = 0; log_index < LOG_NUMBER; log_index = log_index + 1) begin : g_log_collision
      localparam POSX_BIAS = log_index * X_BITS;
      localparam POSY_BIAS = log_index * Y_BITS;
      localparam SIZEX_BIAS = log_index * MAX_OBJ_WIDTH_BITS;
      localparam SIZEY_BIAS = log_index * MAX_OBJ_HEIGHT_BITS;

      // failure to hit a log results in death
      check_overlap  #(      .X_BITS(X_BITS),
      .Y_BITS(Y_BITS),
      .MAX_OBJ_WIDTH_BITS(MAX_OBJ_WIDTH_BITS),
      .MAX_OBJ_HEIGHT_BITS(MAX_OBJ_HEIGHT_BITS)) overlap(
          .frog_pos_x(frog_pos[X_BITS-1: 0]),
          .obj_pos_x(log_pos[X_BITS-1+POSX_BIAS:POSX_BIAS]),
          .obj_size_x(
              log_size[MAX_OBJ_WIDTH_BITS-1+SIZEX_BIAS:SIZEX_BIAS]
          ),
         .frog_pos_y(frog_pos[Y_BITS+X_BITS-1:X_BITS]),
          .obj_pos_y(log_pos[Y_BITS-1+X_BITS*LOG_NUMBER+POSY_BIAS:X_BITS*LOG_NUMBER+POSY_BIAS]),
          .obj_size_y(log_size[LOG_NUMBER*MAX_OBJ_WIDTH_BITS+MAX_OBJ_HEIGHT_BITS-1+SIZEY_BIAS
          :MAX_OBJ_WIDTH_BITS*LOG_NUMBER+SIZEY_BIAS]
),
          .overlap(hit[log_index])

      );
    end
  endgenerate
  
    assign death_int = (hit == 0) ? 1'b1 : 1'b0;
    
  always @(posedge clk) begin

    if (reset == 1'b0) death <= 1'b0;
    else begin
      death <= death_int;
    end
  end


endmodule
