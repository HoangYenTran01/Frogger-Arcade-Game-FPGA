// detect whether the frog dies in the road region

module road_death (
    clk,
    reset,
    frog_pos,
    car_pos,
    car_size,
    death
);
  parameter CAR_NUMBER = 3;
  parameter [1:0] DEATH = 2'b01, HOME = 2'b10, SAFE = 2'b00;  // collision types
  parameter SCREEN_WIDTH = 40;
  parameter SCREEN_HEIGHT = 14;
  parameter [2:0] VOID = 3'b000, FROG = 3'b001, CAR = 3'b010, LOG = 3'b011;  // object type
  parameter X_BITS = $clog2(SCREEN_WIDTH);
  parameter Y_BITS = $clog2(SCREEN_HEIGHT);
  parameter MAX_OBJ_WIDTH_BITS = 4;
  parameter MAX_OBJ_HEIGHT_BITS = 2;

  input clk, reset;
  // positions in {..., ypos1, y-pos0, ..., xpos1, xpos0}
  input [CAR_NUMBER*(Y_BITS+X_BITS)-1:0] car_pos;
  // sizes in {..., obj1height, obj0height, ..., obj1width, obj0width}
  input [CAR_NUMBER*(MAX_OBJ_WIDTH_BITS+MAX_OBJ_HEIGHT_BITS)-1:0] car_size;
  // frog position in {frogpos_y, frogpos_x}
  input [X_BITS+Y_BITS-1:0] frog_pos;
  output death;  // death signal is active high
wire death_int;
  wire [CAR_NUMBER-1:0] hit;  // whether frog hits car number i where i is the index

  genvar car_index;
  generate
    for (car_index = 0; car_index < CAR_NUMBER; car_index = car_index + 1) begin : g_car_collision
      localparam POSX_BIAS = car_index * X_BITS;
      localparam POSY_BIAS = car_index * Y_BITS;
      localparam SIZEX_BIAS = car_index * MAX_OBJ_WIDTH_BITS;
      localparam SIZEY_BIAS = car_index * MAX_OBJ_HEIGHT_BITS;

      // hitting a car results in death
      check_overlap #(      .X_BITS(X_BITS),
      .Y_BITS(Y_BITS),
      .MAX_OBJ_WIDTH_BITS(MAX_OBJ_WIDTH_BITS),
      .MAX_OBJ_HEIGHT_BITS(MAX_OBJ_HEIGHT_BITS)) overlap(
          .frog_pos_x(frog_pos[X_BITS-1: 0]),
          .obj_pos_x(car_pos[X_BITS-1+POSX_BIAS:POSX_BIAS]),
          .obj_size_x(
              car_size[MAX_OBJ_WIDTH_BITS-1+SIZEX_BIAS:SIZEX_BIAS]
          ),
          .frog_pos_y(frog_pos[Y_BITS+X_BITS-1:X_BITS]),
          .obj_pos_y(car_pos[Y_BITS-1+X_BITS*CAR_NUMBER+POSY_BIAS:X_BITS*CAR_NUMBER+POSY_BIAS]),
          .obj_size_y(car_size[CAR_NUMBER*MAX_OBJ_WIDTH_BITS+MAX_OBJ_HEIGHT_BITS-1+SIZEY_BIAS
          :MAX_OBJ_WIDTH_BITS*CAR_NUMBER+SIZEY_BIAS]
),
          .overlap(hit[car_index])

      );
    end
  endgenerate

      assign death = (hit == 0) ? 1'b0 : 1'b1;
//  always @(posedge clk) begin

//    if (reset == 1'b0) death <= 1'b0;
//    else begin
//      death <= death_int;
//    end
//  end


endmodule
