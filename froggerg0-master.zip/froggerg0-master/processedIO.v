`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/01/2025 08:23:40 PM
// Design Name: 
// Module Name: processedIO
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

///////Top module to process the button click, making sure only 1 movement per click///////
//////////Also use debounce to check/////////
module processedIO(clk, reset, movement, processedsignal);
	input clk;
	input reset;
	input [3:0]movement;
 	output [3:0] processedsignal;
 	wire [3:0] w1;
	debouncer upmovement(.clk(clk), .reset(reset), .insignal(movement[0]), .outsignal(w1[0]));
	processperclick upmove(.clk(clk), .reset(reset), .signalprocess(w1[0]), .clicked(processedsignal[0]));
	
	debouncer rightmovement(.clk(clk), .reset(reset), .insignal(movement[1]), .outsignal(w1[1]));
	processperclick rightmove(.clk(clk), .reset(reset), .signalprocess(w1[1]), .clicked(processedsignal[1]));
	
	debouncer leftmovement(.clk(clk), .reset(reset), .insignal(movement[2]), .outsignal(w1[2]));
	processperclick leftmove(.clk(clk), .reset(reset), .signalprocess(w1[2]), .clicked(processedsignal[2]));
	
	debouncer downmovement(.clk(clk), .reset(reset), .insignal(movement[3]), .outsignal(w1[3]));
	processperclick downmove(.clk(clk), .reset(reset), .signalprocess(w1[3]), .clicked(processedsignal[3]));

endmodule
